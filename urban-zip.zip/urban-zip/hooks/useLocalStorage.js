import toast from "react-hot-toast";

export const useLocalStorage = (key = "") => {
  const setProduct = (id, size) => {
    try {
      var existingArray = window.localStorage.getItem(key);
      if (existingArray) {
        existingArray = JSON.parse(existingArray);

        const isIdPresent = existingArray.some((item) => item.id === id);

        if (!isIdPresent) {
          existingArray.push({ id, size });
          toast.success("Product added to cart");
        } else {
          toast.error("Item Already added");
        }
      } else {
        existingArray = [{ id, size }];
        toast.success("Product added to cart");
      }
      window.localStorage.setItem(key, JSON.stringify(existingArray));
    } catch (error) {
      toast.error(
        "something went wrong!! while adding Product please try again"
      );
    }
  };
  const getProduct = () => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : undefined;
    } catch (error) {
      toast.error(
        "something went wrong!! while getting the product please try again"
      );
    }
  };
  return { setProduct, getProduct };
};
