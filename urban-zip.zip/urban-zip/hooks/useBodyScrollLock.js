
import { useLayoutEffect } from 'react';
// import { disableBodyScroll, enableBodyScroll } from 'body-scroll-lock';

const useBodyScrollLock = isOpen => {
  useLayoutEffect(() => {
    if (isOpen) {
      // Lock the body scroll when the component mounts
      // const targetElement = document.querySelector('body');
      // disableBodyScroll(targetElement);
      document.body.style.overflow = 'hidden';

      // Unlock the body scroll when the component unmounts
      return () => {
        // enableBodyScroll(targetElement);
        document.body.style.overflow = 'visible';
      };
    }
  }, [isOpen]);

  return null; // This hook doesn't render anything
};

export default useBodyScrollLock;
