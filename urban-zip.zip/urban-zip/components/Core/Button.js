import React from "react";

const Button = ({ children, className, ...props }) => {
  return (
    <>
      <button
        type="button"
        {...props}
        className={"btn-rrot" + className}
      >
        {children}
      </button>
    </>
  );
};

export default Button;
