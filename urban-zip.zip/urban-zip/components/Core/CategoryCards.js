"use client"
import Image from "next/image";
import Link from "next/link";
import React from "react";



const CategoryCards = ({categoryData}) => {
  
  return (
    <div className="listing-category-card">
      {categoryData.map((category,i) => {
        return <Card key={i} image={category.img} category={category.value} url={category?.url} />;
      })}
    </div>
  );
};
const Card = ({ image, category,url }) => {

  return (
    <Link href={`${url}`}>
    <div className="category-card" >
      <div className="content">
        <Image src={image} width={80} height={80} />
        <h3>{category}</h3>
      </div>
    </div>
    </Link>
  );
};

export default CategoryCards;
