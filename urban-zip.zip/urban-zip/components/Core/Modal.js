import React from "react";
import Modal from "react-modal";

const ModalComponent = ({ isOpen, closeModal, children, widthValue,heightValue ,marginTopValue,paddingValue}) => {
  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={closeModal}
      style={{
        overlay: {
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        },
        content: {
          width: widthValue ??"40%",
          height: heightValue ?? "30%",
          margin: "auto",
          marginTop: marginTopValue ??"100px",
          padding: paddingValue ?? "30px",
        },
      }}
    >
      {children}
    </Modal>
  );
};

export default ModalComponent;
