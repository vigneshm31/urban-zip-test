import React, { useState,useEffect } from "react";
import { Formik, Field, Form, ErrorMessage, useFormik } from "formik";
import * as Yup from "yup";
import {useFormState} from "react-dom"
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

const SignUp = ({ register }) => {
  const [isChecked, setIsChecked] = useState(false);
  const [isValidAdminCode, setIsValidAdminCode] = useState(false);
  const router=useRouter()

  const initialValues = {
    userName: "",
    mobileNumber: "",
    email: "",
    password: "",
    confirmPassword: "",
  };
  const validationSchema = Yup.object({
    userName: Yup.string().required(),
    mobileNumber: Yup.string()
      .min(10, "Mobile number must be 10 digits")
      .max(10, "Mobile number must be 10 digits")
      .required()
      .matches(/^[0-9]*$/, "Invalid mobile number")
      .test(
        "nonZeroStart",
        "Invalid mobile number",
        (value) => value && value[0] !== "0"
      ),
    email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
    password: Yup.string().required(),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password"), null], "Passwords must match")
      .required("Confirm password is required"),
  });
  const handleAdminCodeChange = (e) => {
    const { value } = e.target;
    if (value) {
      const isValid = value === "12345" ? true : false;
      setIsValidAdminCode(isValid);
    }
  };
  const checkForAdmin = isChecked && isValidAdminCode ? true : false;
  // const handleRegisterForm = register.bind(null, checkForAdmin);
  const [state,formAction]=useFormState(register,undefined)


  useEffect(() => {
    if (state?.success) {
      toast.success("Register successful")
      router.push("/")
    }else if (state?.error){
      toast.error(state.error)
    }
    
  }, [state]);
  return (
    <div className="form-container-auth">
      {/* <div className="header">REGISTER</div> */}
      <div className="main">
        <div>
          <p className="heading-text">Contact Details </p>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            // onSubmit={onSubmit}
            enableReinitialize={true}
          >
            {({
              values,
              handleSubmit,
              isSubmitting,
              setFieldValue,
              touched,
              errors,
              isValid,
            }) => (
              <>
              <form action={formAction}>
                <div className="field-and-error-container">
                  <div className="form">
                    <Field
                      name="userName"
                      label="Enter Name *"
                      className="form__input"
                      type="text"
                      placeholder=""
                      id="userName"

                    />
                    <label htmlFor="userName" className="form__label">
                      Enter Name*
                    </label>
                  </div>
                  <ErrorMessage
                    component="div"
                    name="userName"
                    className="form-input-error"
                  />
                </div>
                <div className="field-and-error-container">
                  <div className="form">
                    <Field
                      name="mobileNumber"
                      label="Mobile No* *"
                      className="form__input"
                      type="text"
                      placeholder=""
                      id="mobileNumber"
                    />
                    <label htmlFor="mobileNumber" className="form__label">
                      Mobile No*
                    </label>
                  </div>
                  <ErrorMessage
                    component="div"
                    name="mobileNumber"
                    className="form-input-error"
                  />
                </div>
                <div className="field-and-error-container">
                  <div className="form">
                    <Field
                      name="email"
                      label="Email Id* *"
                      className="form__input"
                      type="text"
                      placeholder=""
                      id="email"
                    />
                    <label htmlFor="email" className="form__label">
                      Email Id*
                    </label>
                  </div>
                  <ErrorMessage
                    component="div"
                    name="email"
                    className="form-input-error"
                  />
                </div>

                <p className="heading-text">Password </p>
                <div className="field-and-error-container">
                  <div className="form">
                    <Field
                      name="password"
                      label="Enter Password* *"
                      className="form__input"
                      type="password"
                      placeholder=""
                      id="password"
                    />
                    <label htmlFor="password" className="form__label">
                      Enter Password*
                    </label>
                  </div>
                  <ErrorMessage
                    component="div"
                    name="password"
                    className="form-input-error"
                  />
                </div>
                <div className="field-and-error-container">
                  <div className="form">
                    <Field
                      name="confirmPassword"
                      label="Retype Password* *"
                      className="form__input"
                      type="password"
                      placeholder=""
                      id="confirmPassword"
                    />
                    <label htmlFor="confirmPassword" className="form__label">
                      Retype Password*
                    </label>
                  </div>
                  <ErrorMessage
                    component="div"
                    name="confirmPassword"
                    className="form-input-error"
                  />
                </div>

                {/* <div className="form form-checkbox">
                  <Field
                    type="checkbox"
                    name="isAdmin"
                    className="form-input-checkbox"
                    autocomplete="off"
                    placeholder=" "
                    checked={isChecked}
                    onClick={() => setIsChecked(!isChecked)}
                  />
                  <label
                    htmlFor="defaultaddress"
                    className="form-label-checkbox"
                  >
                    Is Admin (optional)
                  </label>
                  {isChecked && (
                    <div className="field-and-error-container">
                      <div className="form">
                        <Field
                          name="admincode"
                          label="Admin Code* *"
                          className="form__input"
                          type="text"
                          placeholder=""
                          onChange={handleAdminCodeChange}
                                                    id="admincode"

                        />
                        <label
                          htmlFor="confirmPassword"
                          className="form__label"
                        >
                          Enter Admin code
                        </label>
                      </div>
                      <ErrorMessage
                        component="div"
                        name="admincode"
                        className="form-input-error"
                      />
                    </div>
                  )}
                  {isChecked && isValidAdminCode && (
                    <span className="tick-icon">&#10003;</span>
                  )}
                </div> */}
                <div className="footer-btn">
                  <div className="save-address-btn">
                    <button
                      type="submit"
                      // onClick={handleSubmit}
                      disabled={!isValid || isSubmitting}
                    >
                      Register
                    </button>
                  </div>
                </div>
              </form>
              {state?.error && <p className="auth-error">{state?.error}</p>}
              </>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
