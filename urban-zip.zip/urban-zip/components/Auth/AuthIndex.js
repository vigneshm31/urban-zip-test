"use client";
import React, { useState } from "react";
import Login from "@/components/Auth/Login";
import SignUp from "@/components/Auth/SignUp";
import Image from "next/image";

const AuthIndex = ({register,userLogin,}) => {
  const [selectedTab, setSelectedTab] = useState(0);
  const tabDetails = [
    {
      title: "Login",
      content: <Login userLogin={userLogin}/>,
    },
    {
      title: "SignUp",
      content: <SignUp register={register} />,
    },
  ];
  const handleTabClick = (i) => {
    setSelectedTab(i);
  };
  return (
    <>
      <div className="auth-container">
        {/* <Image src={"/images/loginbanner.png"} width={400} height={160} /> */}
        <div className="signin-container">
          <div className="tab">
            {tabDetails.map((tab, i) => (
              <div
                className={`tab-title ${i === selectedTab && "active"}`}
                onClick={() => handleTabClick(i)}
                key={i}
              >
                {tab.title}
              </div>
            ))}
          </div>
          <div className="tab-content">
            {tabDetails[selectedTab] && <>{tabDetails[selectedTab].content}</>}
          </div>
        </div>
      </div>
    </>
  );
};

export default AuthIndex;
