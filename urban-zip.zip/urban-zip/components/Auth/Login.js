import React, { useEffect } from "react";
import { Formik, Field, Form, ErrorMessage, useFormik } from "formik";
import { useFormState } from "react-dom";
import * as Yup from "yup";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";
const Login = ({ userLogin }) => {
  const [state, formAction] = useFormState(userLogin, undefined);
  const router = useRouter();
  const initialValues = {
    userName: "",
    password: "",
  };
  const validationSchema = Yup.object({
    userName: Yup.string().required(),
    password: Yup.string().required(),
  });
  useEffect(() => {
    if (state?.success) {
      toast.success("Login successful");

      const redirectUrl = new URLSearchParams(window.location.search).get(
        "redirect"
      );

      if (redirectUrl) {
        router.push(redirectUrl);
      } else {
        router.push("/");
      }
    }else if (state?.error){
      toast.error(state.error)
    }
  }, [state]);
  return (
    <div className="form-container-auth">
      {/* <div className="header">REGISTER</div> */}
      <div className="main">
        <div>
          <p className="heading-text">Contact Details </p>

          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            enableReinitialize={true}
          >
            {({
              values,
              handleSubmit,
              isSubmitting,
              setFieldValue,
              touched,
              errors,
              isValid,
            }) => (
              <>
                <form action={formAction}>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        name="userName"
                        label="Enter Name *"
                        className="form__input"
                        type="text"
                        placeholder=""
                        id="userName"
                      />
                      <label htmlFor="userName" className="form__label">
                        Enter Name*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="userName"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        name="password"
                        label="Enter Password* *"
                        className="form__input"
                        type="password"
                        placeholder=""
                        id="password"
                      />
                      <label htmlFor="password" className="form__label">
                        Enter Password*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="password"
                      className="form-input-error"
                    />
                  </div>

                  <div className="footer-btn">
                    <div className="save-address-btn">
                      <button type="submit" disabled={!isValid || isSubmitting}>
                        Login
                      </button>
                    </div>
                  </div>
                </form>
                {state?.error && <p className="auth-error">{state?.error}</p>}
              </>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default Login;
