import React from 'react'

const TopBrands = () => {
  return (
    <div className="top-brands-container">
        <div className="heading-container">
        <h2 className="heading">Top Brands</h2>
        <p className="para"> Best Brands at greater discounts !</p>
      </div>

      <div className="brand-img-container">
        <img src="https://assets.ajio.com/cms/AJIO/WEB/05052023-UHP-Ajiomania-TopBrandsforyourgetaway-D-P1-Puma-Min50.jpg" alt="" />
        <img src="https://assets.ajio.com/cms/AJIO/WEB/05052023-UHP-Ajiomania-TopBrandsforyourgetaway-D-P2-Nike-Upto50.jpg" alt="" />
        <img src="https://assets.ajio.com/cms/AJIO/WEB/05052023-UHP-Ajiomania-TopBrandsforyourgetaway-D-P3-Adidas-Min50.jpg" alt="" />
      </div>

    </div>
  )
}

export default TopBrands