import React, { useEffect, useState } from "react";
import ModalComponent from "@/components/Core/Modal";
import useBodyScrollLock from "@/hooks/useBodyScrollLock";
import AddressForm from "@/components/Checkout/Address/AddressForm";
import { MdOutlineRadioButtonChecked } from "react-icons/md";

const Address = ({ addAddressToDb, addresses }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  useBodyScrollLock(isModalOpen);

  const parsedAddress = JSON.parse(addresses);

  return (
    <>
      <div className="heading-btn-container">
        <h2 className="heading">Select Delivery Address</h2>
        <button className="add-address-btn" onClick={() => openModal()}>
          Add New Address
        </button>
      </div>
      <div className="address-container">
        <ModalComponent
          isOpen={isModalOpen}
          closeModal={closeModal}
          widthValue="440px"
          heightValue="80%"
          marginTopValue="20px"
          paddingValue="10px"
        >
          <AddressForm
            closeModal={closeModal}
            addAddressToDb={addAddressToDb}
          />
        </ModalComponent>

        <div className="address-lists">
          <section className="default-address-container">
            {parsedAddress?.length>0  && <p className="heading">Default Address</p>}
            {parsedAddress?.length>0 &&
              parsedAddress?.map((address,i) => (
                <div className="address" key={i}>
                  <div className="content">
                    <MdOutlineRadioButtonChecked />
                    <div className="customer-details">
                      <p className="customer-name">{address.customername?? "vignesh"} </p>
                      <div className="customer-address">
                        {address.street},{address.locality},{address.city} 
                        {/* 2/175,pallapatti,near marutham nelli polytechnic college, Pallapatti, near Indur */}
                      </div>
                      <div className="customer-mobile">Mobile: {address.mobilenumber ?? "7867575654"}</div>
                      <div className="remove-edit-btn">
                        <button className="remove">REMOVE</button>
                        <button>EDIT</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              {
                parsedAddress.length ===0 &&  <div className="no-product-found">
                <span>Sorry, No address Found, add new Address </span>
              </div>
              }
          </section>
        </div>
      </div>
    </>
  );
};

export default Address;
