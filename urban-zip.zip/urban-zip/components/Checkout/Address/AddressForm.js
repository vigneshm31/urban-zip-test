"use client"
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Formik, Field, Form, ErrorMessage, useFormik } from "formik";
import * as Yup from "yup";
import Input from "@/components/Input";
import { MdClose } from "react-icons/md";
import { debounce } from "lodash";
import { MdOutlineFileUpload } from "react-icons/md";
import { getUserData } from "@/utils";
import {useFormState} from "react-dom"
import { useRouter } from "next/navigation";



const AddressForm = ({ closeModal,addAddressToDb }) => {
  const [pincode, setPincode] = useState("");
  const [addresses, setAddresses] = useState([]);
  const [district, setDistrict] = useState("");
  const [states, setStates] = useState("");

  const [userTypedPostOffice,setuserTypedPostOffice]=useState("")
  const [listpostOffices,setListPostOffices]=useState([])
  const [suggestedPostOfficeList,setsuggestedPostOfficeList]=useState([])
  const [userData, setUserData] = useState(null);
  const [state,formAction]=useFormState(addAddressToDb,undefined)
  const router=useRouter()




  useEffect(() => {
    if (addresses?.length > 0) {
      const firstOfficeWithDistrict = addresses.find(
        (office) => office?.District
      );
      const firstOfficeWithState = addresses.find((office) => office?.State);

      if (firstOfficeWithDistrict) {
        setDistrict(firstOfficeWithDistrict?.District);
      }

      if (firstOfficeWithState) {
        setState(firstOfficeWithState?.State);
      }
    }
  }, [addresses]);
  const handlePincodeChange = debounce(async (value) => {
    setPincode(value);

    // Make an API request to fetch address suggestions
    if (value.length === 6) {
      axios
        .get(`https://api.postalpincode.in/pincode/${value}`)
        .then((response) => {
          const data = response.data;
          if (data[0].Status === "Success") {
            const suggestions = data[0].PostOffice.map((office) => office);
            setAddresses(suggestions);
            setDistrict(suggestions[0]?.District || "");
            setStates(suggestions[0]?.State || "");
            const lisOfPostOffices=suggestions.map(data=>data.Name)
            setListPostOffices(lisOfPostOffices)
            // setPincode("")
          } else {
            setAddresses([]);
            setDistrict("");
            setStates("");
          }
        })
        .catch((error) => {
          console.log(error);
          setAddresses([]);
          setDistrict("");
          setStates("");
        });
    } else {
      setAddresses([]);
      setDistrict("");
      setStates("");
    }
  }, 100);
  const initialValues = {
    customername: "",
    mobilenumber: "",
    pincode: "",
    street: "",
    locality: "",
    city:"",
    state: "",
  };
  const pincodeRegex = /^[1-9][0-9]{5}$/;

  const validationSchema = Yup.object({
    customername: Yup.string().required(),

    mobilenumber: Yup.string()
      .min(10, "Mobile number must be 10 digits")
      .max(10, "Mobile number must be 10 digits")
      .required()
      .matches(/^[0-9]*$/, "Invalid mobile number")
      .test(
        "nonZeroStart",
        "Invalid mobile number",
        (value) => value && value[0] !== "0"
      ),
    pincode: Yup.string()
      .min(6, "Pincode number must be 6 digits")
      .max(6, "Pincode number must be 6 digits")
      .required()
      .matches(/^[0-9]*$/, "Invalid Pincode number")
      .test(
        "nonZeroStart",
        "Invalid Pincode number",
        (value) => value && value[0] !== "0"
      ),

    street: Yup.string().required(),
    locality: Yup.string().required(),
    city: Yup.string().required(),

    state: Yup.string().required(),
    // defaultaddress: Yup.boolean(),
  });
  const onKeyDown = (keyEvent) => {
    if ((keyEvent.charCode || keyEvent.keyCode) === 13) {
      keyEvent.preventDefault();
    }
  };
  const onSubmit = (values, onSubmitProps) => {
    const {
      customername,
      mobilenumber,
      pincode,
      street,
      locality,
      city,
      state,
      defaultaddress,
    } = values;

    let bodyToPass = {
      customername,
      mobilenumber,
      pincode,
      street,
      locality,
      city,
      state,
      defaultaddress,
    };
    const updatedItems = [...items, bodyToPass];
    setItems(updatedItems);
    onSubmitProps.setSubmitting(false);
    onSubmitProps.resetForm();
    toast.success("Product Published Successfully", {
      icon: <MdOutlineFileUpload />,
      style: {
        borderRadius: "5px",
        background: "#f5f6fa",
        color: "#000",
        fontWeight: "600",
      },
    });
    router.push("/my-account/products");
  };
  const handleChange = debounce(async (value) => {
    setuserTypedPostOffice(value);
  }, 1000);
  useEffect(() => {
    if (userTypedPostOffice) {
      const searchData = listpostOffices?.filter((place) =>
        place.toLowerCase().includes(userTypedPostOffice.toLowerCase())
      );
      setsuggestedPostOfficeList(searchData);
    } else {
      setsuggestedPostOfficeList([]);
    }
  }, [userTypedPostOffice]);

  useEffect(() => {
    if (state?.success) {
      closeModal();
    }
    
  }, [state]);
  return (
    <div className="address-form-modal-container">
      <div className="closeicon" onClick={() => closeModal()}>
        <MdClose />
      </div>
      <div className="form-container-address">
        <div className="header-address">ADD NEW ADDRESS</div>
        <div className="main-address">
          <div>
            <p className="heading-text">Contact Details </p>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              // onSubmit={onSubmit}
              enableReinitialize={true}
            >
              {({
                values,
                handleSubmit,
                isSubmitting,
                setFieldValue,
                touched,
                errors,
                isValid,
              }) => (
                <form action={formAction}>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        name="customername"
                        label="Name *"
                        className="form__input"
                        type="text"
                        infoMessage="Name"
                        placeholder=""
                        id="customername"
                      />
                      <label htmlFor="customername" className="form__label">
                        Name*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="customername"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        name="mobilenumber"
                        label="Mobile No* *"
                        className="form__input"
                        type="text"
                        infoMessage="mobilenumber"
                        placeholder=""
                        id="mobilenumber"
                      />
                      <label htmlFor="mobilenumber" className="form__label">
                        Mobile No*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="mobilenumber"
                      className="form-input-error"
                    />
                  </div>

                  <p className="heading-text">Address </p>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        type="text"
                        name="pincode"
                        className="form__input"
                        autocomplete="off"
                        // value={pincode}
                        placeholder=""
                        // onChange={(e) => handlePincodeChange(e.target.value)}
                        id="pincode"
                      />
                      <label htmlFor="pincode" className="form__label">
                        Pin Code*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="pincode"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        type="text"
                        name="street"
                        className="form__input"
                        autocomplete="off"
                        placeholder=" "
                        id="street"
                      />
                      <label htmlFor="street" className="form__label">
                        Address (House No, Building, Street, Area)*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="street"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                  <div className="form">
                      <Field
                        type="text"
                        name="locality"
                        className="form__input"
                        autocomplete="off"
                        placeholder=" "
                        // onChange={(e)=>handleChange(e.target.value)}
                        id="locality"

                      />
                      <label htmlFor="locality" className="form__label">
                        Locality/ Post office
                      </label>
                    </div>
                    {/* {
                      suggestedPostOfficeList.length && suggestedPostOfficeList.map(place=>(
                        <p style={{zIndex:"9999"}}>{place}</p>
                      ))
                    } */}
                    <ErrorMessage
                      component="div"
                      name="locality"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        type="text"
                        name="city"
                        className="form__input"
                        autocomplete="off"
                        placeholder=" "
                        // value={district}
                        id="city"
                      />
                      <label htmlFor="city" className="form__label">
                        City/District*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="city"
                      className="form-input-error"
                    />
                  </div>
                  <div className="field-and-error-container">
                    <div className="form">
                      <Field
                        type="text"
                        name="state"
                        className="form__input"
                        autocomplete="off"
                        placeholder=" "
                        // value={state}
                        id="state"
                      />
                      <label htmlFor="state" className="form__label">
                        State*
                      </label>
                    </div>
                    <ErrorMessage
                      component="div"
                      name="state"
                      className="form-input-error"
                    />
                  </div>

                  <div className="form form-checkbox">
                    <Field
                      type="checkbox"
                      name="defaultaddress"
                      className="form-input-checkbox"
                      autocomplete="off"
                      placeholder=" "
                    />
                    <label
                      htmlFor="defaultaddress"
                      className="form-label-checkbox"
                    >
                      Make this my default address
                    </label>
                  </div>
                  <div className="footer-btn">
                    <div className="save-address-btn">
                      <button
                        // type="submit"
                        // onClick={handleSubmit}
                        disabled={!isValid || isSubmitting}
                      >
                        Add Address
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddressForm;
