"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { IoHomeOutline } from "react-icons/io5";
import { CiSearch, CiHeart } from "react-icons/ci";
import { AiOutlineUser } from "react-icons/ai";
import { BiCategory } from "react-icons/bi";


const NavbarMain = ({ session, userLogout }) => {
  const [cartItems, setCartItems] = useState([]);
  const [open, setopen] = useState(false);
  const footerMenu=[
    {
      id: 1,
      name: "Home",
      href: "/",
      icon: <IoHomeOutline />,
    },
    {
      id: 2,
      name: "Browse",
      href: "/search",
      icon: <CiSearch />,
    },
    {
      id: 3,
      name: "WishList",
      href: "/wislist",
      icon: <CiHeart />,
    },
    {
      id: 4,
      name: "Category",
      href: "/category",
      icon: <BiCategory />,
    },
    {
      id: 4,
      name: "Account",
      href: "/account",
      icon: <AiOutlineUser />,
    },
  ];

  useEffect(() => {
    const existingCartData =
      JSON.parse(localStorage.getItem("listCartItems")) || [];
    setCartItems(existingCartData);
  }, []);
  const router = usePathname();
  const isActiveItem = (item) => {
    if (router?.includes("/men") && item === "Men") {
      return true;
    } else if (router?.includes("/women") && item === "Women") {
      return true;
    } else if (router?.includes("/kids") && item === "Kids") {
      return true;
    } else {
      return false;
    }
  };
  return (
    <div className="main-footer-container">
      <div className="navbar-content">
        <div className="navbar-menu-container">
          <ul className="list-menu">
            {footerMenu?.map((menu, i) => (
              <li className="list-content" key={i}>
                <Link
                  className={`list ${isActiveItem(menu?.name) && "active"}`}
                  href={`${menu.href}`}
                >
                 <div className="list-names">
                  <span>{menu?.icon}</span>
                  <p>{menu.name}</p>
                  </div> 
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
export default NavbarMain;
