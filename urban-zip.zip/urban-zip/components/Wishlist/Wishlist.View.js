"use client";
import Link from "next/link";
import React, { useState, useEffect } from "react";
import ProductTile from "@/components/ProductTile";
import { FiMapPin } from "react-icons/fi";
import Spinner from "../Core/Spinner";

const WishlistView = ({
  getProductByProductIdsForCartFromDB,
  wishListProductIDs,
}) => {
  const [wishlistProductItems, setWishListProductItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    if (wishListProductIDs) {
      const getwishlistItemsFromDB =
        await getProductByProductIdsForCartFromDB.bind(
          null,
          wishListProductIDs
        );
      try {
        const response = await getwishlistItemsFromDB();
        setWishListProductItems(response);
        setLoading(false);
      } catch (error) {
        console.log(error);
      }
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <>
    <div className="heading-container">
        <h2 className="heading">Wishlisted Products</h2>
        {/* <p className="para"> Best Products at greater discounts !</p> */}
      </div>
      {loading ? (
        <Spinner />
      ) : (
        <div className="listing-cards-container">
            
          {wishlistProductItems?.length > 0 &&
            wishlistProductItems?.map((item, i) => {
              return (
                <Link href={`/${item?.category}/${item?.productId}`} key={i}>
                  <ProductTile
                    id={item.id}
                    brand={item.brand}
                    color={item.color}
                    size={item.size}
                    image={item.image}
                    price={item.price}
                    deliveryType={item.deliveryType}
                    isWhishList={item.isWhishList}
                    item={item}
                    mrp={item.mrp}
                    rating={item.rating}
                    totalRating={item.totalRating}
                    {...item}
                  />
                </Link>
              );
            })}
          {wishlistProductItems?.length === 0 && (
            <div className="no-product-found">
              <FiMapPin />
              <span>Sorry, No Data Found </span>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default WishlistView;
