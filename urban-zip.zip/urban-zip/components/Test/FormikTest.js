"use client"
import React from 'react'
import { Formik, Field, useFormik } from "formik";
import * as Yup from "yup";
const FormikTest = () => {
    const initialValuesUseFormik = {
        brand: "",
        price: "",
      };
      const onSubmitUseFormik = (values) => {
        console.log(values);
      };
      const onValidateUseFormik = (values) => {
        console.log(values);
        let errors = {};
        if (!values.brand) {
          errors.brand = "this is required";
        }if (!values.price) {
            errors.price = "this is required";
          }
        return errors;
      };
      const validationSchema = Yup.object({
        brand: Yup.string().required("req"),
      });
    
      const formik = useFormik({
        initialValues: initialValuesUseFormik,
        onSubmit: onSubmitUseFormik,
        // validate: onValidateUseFormik,
        validationSchema,
      });
  return (
    
          <div>
            <form onSubmit={formik.handleSubmit}>
              <div
                style={{
                  display: "flex",
                  gap: "10px",
                  flexDirection: "column",
                  width: "200px",
                }}
              >
                <label htmlFor="brand">Brand</label>
                <input
                  type="text"
                  name="brand"
                  value={formik.values.brand}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.touched.brand && formik.errors.brand ? (
                  <p>{formik.errors.brand}</p>
                ) : null}
                <label htmlFor="brand">Price</label>
                <input
                  type="text"
                  name="price"
                  // value={formik.values.price}
                  // onChange={formik.handleChange}
                  // onBlur={formik.handleBlur}
                  {...formik.getFieldProps("price")}
                />
                {formik.touched.price && formik.errors.price ? (
                  <p>{formik.errors.price}</p>
                ) : null}
                <button type="submit">Submit</button>
              </div>
            </form>
          </div>
       
  )
}

export default FormikTest