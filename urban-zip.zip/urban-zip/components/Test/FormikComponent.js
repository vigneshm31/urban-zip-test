"use client";
import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const FormikComponent = () => {
  const initialValues = {
    brand: "",
    price: "",
  };
  const onSubmit = (values) => {
   
  };

  const validationSchema = Yup.object({
    brand: Yup.string().required("req"),
    price: Yup.string().required("req"),
  });
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      <Form>
        <div
          style={{
            display: "flex",
            gap: "10px",
            flexDirection: "column",
            width: "200px",
          }}
        >
          <label htmlFor="brand">Brand</label>
          <Field type="text" name="brand" />
          <ErrorMessage name="brand" />
          <label htmlFor="brand">Price</label>
          <Field type="text" name="price" />
          <ErrorMessage name="price" />
          <button type="submit">Submit</button>
        </div>
      </Form>
    </Formik>
  );
};

export default FormikComponent;
