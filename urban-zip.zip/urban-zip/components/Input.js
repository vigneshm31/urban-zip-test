import React from "react";
import { ErrorMessage } from "formik";

const Input = ({ ...props }) => {
  let Component = "input";
  if (props.type == "textarea") {
    Component = "textarea";
  }
  if (props.type == "select") {
    Component = "select";
  }
  if (props.type == "div") {
    Component = "div";
  }
  if (props.type == "switch") {
    Component = InputSwitch;
  }
  if (props.type == "tags") {
    Component = InputTags;
  }
  if (props.type == "checkbox") {
    Component = "checkbox";
  }
  if (props.type == "radio") {
    Component = "radio";
  }
  props.className = "form-control " + (props.className || "");
  return (
    <div className="form-group">
      {props.label && (
        <>
          <label htmlFor={props.name} className="form-label">
            {props.label}
          </label>
          {props.infoMessage && (
            <span className="tooltip-info">
              {/* <Tooltip
                                className="display-left"
                                info={props.infoMessage}
                            /> */}
            </span>
          )}
        </>
      )}
      <Component {...props} />
      <ErrorMessage
        component="div"
        name={props.name}
        className="form-input-error"
      />
    </div>
  );
};

export default Input;
