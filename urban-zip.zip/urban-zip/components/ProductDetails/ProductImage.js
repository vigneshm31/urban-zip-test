"use client"
import React from 'react'



const ProductImage = ({imgUrl}) => {
 
  const imgSetUrl= typeof imgUrl==="string" ? imgUrl :imgUrl.src
  return (
    <div className="product-image">
        <img src={imgSetUrl ?? imgUrl} alt="" />
    </div>
  )
}

export default ProductImage