"use client";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { TiStarFullOutline } from "react-icons/ti";
import { BsCurrencyRupee, BsFillHandbagFill } from "react-icons/bs";
import { AiOutlineHeart, AiFillHeart } from "react-icons/ai";
// import { useStateContext } from "context/GlobalState";
import Link from "next/link";
import { useNavigate } from "react-router-dom";
import { CiDeliveryTruck } from "react-icons/ci";
import { toast } from "react-hot-toast";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useRouter, usePathname } from "next/navigation";
import { useDispatch } from "react-redux";
import { addToCart } from "@/redux/features/cartSlice";
import { getSession } from "@/utils/server/auth-actions";

const ProductDescription = ({
  _id,
  brand,
  description,
  color,
  delivery,
  price,
  size,
  rating,
  totalRating,
  mrp,
  material,
  productName,
  productImage,
  productId,
  category,
  userCart,
  userWishList,
  userId,
  addWishListToDb,
  removeWishListFromDb,
}) => {
  // const navigate = useNavigate();
  // const isWhishList =wishListItems?.find(item=>item.id ===id)?.isWhishList

  const [getSize, setgetSize] = useState(null);
  const [sizeValidation, setsizeValidation] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [checkItemAdded, setcheckItemAdded] = useState(false);
  const [wishlistItems, setwishlistItems] = useState([]);
  const [isWishlistAdded, setisWishlistAdded] = useState(false);
  const router = useRouter();
  const usePath = usePathname();
  const dispatch = useDispatch();
  const isWhishList = false;
  useEffect(() => {
    //getting datas
    const existingCartData =
      JSON.parse(localStorage.getItem("listCartItems")) || [];

    // const existingWishlistData =
    //   JSON.parse(localStorage.getItem("wishlistItems")) || [];

    //setting and checking items
    setCartItems(existingCartData);
    const isItemAdded = existingCartData?.find(
      (item) => item?.productId === productId
    );
    if (isItemAdded) {
      setcheckItemAdded(true);
    }
    //setting and checking wishlist

    setwishlistItems(userWishList);
    const isWishlisted = userWishList?.find((item) => item === productId);
    if (isWishlisted) {
      setisWishlistAdded(true);
    }
  }, []);

  useEffect(() => {
    if (getSize) {
      localStorage.setItem("listCartItems", JSON.stringify(cartItems));
    }
  }, [cartItems]);

  let discountPercent = 0;
  const discountCalculator = (price, mrp) => {
    const sellingPercent = (price / mrp) * 100;
    discountPercent = 100 - sellingPercent;

    return Math.round(discountPercent);
  };
  const kFormatter = (num) => {
    return Math.abs(num) > 999
      ? Math.sign(num) * (Math.abs(num) / 1000).toFixed(1) + "k"
      : Math.sign(num) * Math.abs(num);
  };
  const handleAddToBag = () => {
    if (!getSize) {
      toast.error("Please select Size of the Item");
      setsizeValidation(true);
      return;
    }
    const listCartItems = {
      productId: productId,
      selectedSize: getSize,
      quantity: 1,
      productName: productName,
      productImage: productImage,
    };
    setCartItems([...cartItems, listCartItems]);
    dispatch(addToCart(listCartItems));
    setcheckItemAdded(true);
    toast.success("Product Added to cart");
  };
  const handleGoToBag = () => {
    // toast.error("product already added, Going to cart");
    router.push("/cart");
  };
  const handlegetSize = (size) => {
    if (getSize === size) {
      setgetSize(null);
    } else {
      setgetSize(size);
    }
  };
  const handleWishList = async (productId) => {
    const session = await getSession();
    if (!session.isLoggedIn) {
      toast.error("Please login to add to wishlist");
      router.push(`/user-auth?redirect=${encodeURIComponent(usePath)}`);
      return;
    }

    const isProductInWishlist = wishlistItems?.includes(productId);

    const updatedWishlist = isProductInWishlist
      ? wishlistItems.filter((id) => id !== productId)
      : [...wishlistItems, productId];

    setwishlistItems(updatedWishlist);
    setisWishlistAdded(!isProductInWishlist);
    localStorage.setItem("wishlistItems", JSON.stringify(updatedWishlist));

    if (isProductInWishlist) {
      await removeWishListFromDb(userId, productId);
      toast.error("Removed from wishlist");
    } else {
      await addWishListToDb(userId, productId);
      toast.success("Added to wishlist");
    }
  };
  // const handleWishList = async(productId) => {
  //   const session =await getSession()
  //     if(!session.isLoggedIn){
  //       toast.error("Please login to add wishlist")
  //       router.push("/user-auth")
  //       return
  //     }
  //   if (wishlistItems?.includes(productId)) {
  //     // If there, remove it
  //     const updatedWishlist = wishlistItems.filter((id) => id !== productId);
  //     setwishlistItems(updatedWishlist);
  //     setisWishlistAdded(false);
  //     localStorage.setItem("wishlistItems", JSON.stringify(updatedWishlist));
  //     await removeWishListFromDb(userId,productId)
  //     toast.error("Removed from wishlist");
  //   } else {
  //     // If not, add it
  //     const updatedWishlist = [...wishlistItems, productId];
  //     setwishlistItems(updatedWishlist);
  //     setisWishlistAdded(true);
  //     localStorage.setItem("wishlistItems", JSON.stringify(updatedWishlist));
  //     await addWishListToDb(userId, productId);

  //     toast.success("Added to wishlist");
  //   }
  //   // localStorage.setItem("wishlistItems",JSON.stringify(wishlistItems))
  // };
  return (
    <div className="pdp-description-container">
      <div className="pdp-price-info">
        <h1 className="pdp-title">{brand}</h1>
        <h1 className="pdp-name">{description}</h1>
        <div className="index-overallRatingContainer">
          <div className="index-overallRating">
            <div className="rating-num">{rating ?? "4.1"}</div>
            <span className="rating-star">
              <TiStarFullOutline />
            </span>
            <div className="index-separator">|</div>
            <div className="index-ratingsCount">
              <span className="total-num">
                {kFormatter(totalRating ?? "6300")}
              </span>
              <span className="total-text">Ratings</span>
            </div>
          </div>
        </div>
        <div className="pdp-discount-container">
          <div className="pdp-price">
            <BsCurrencyRupee />
            <p className="pdp-sell-price">{price}</p>
            <p className="pdp-mrp">
              <span>MRP</span>
              <span className="pdp-mrp-price">
                <BsCurrencyRupee />
                <span>{mrp}</span>
              </span>
            </p>
            <div className="pdp-mrp-discount">
              <p>&#40;</p>
              <p> {discountCalculator(price, mrp)} </p>
              <p>&#37;</p>
              <p>OFF</p>
              <p> &#41;</p>
            </div>
          </div>
          <div>
            <p className="extra-info">inclusive of all taxes</p>
          </div>
        </div>

        {size?.length > 0 && (
          <div className="pdp-size">
            <div className="size-buttons-size-header">
              <h4 className="size-buttons-select-size">SELECT SIZE</h4>
              <span className="size-buttons-size-chart">
                <button className="size-buttons-show-size-chart">
                  SIZE CHART
                </button>
                <span className="size-buttons-arrow"></span>
              </span>
            </div>
            <div className="size-buttons-size-buttons">
              {size?.map((size, i) => (
                <div
                  onClick={() => handlegetSize(size)}
                  className="size-buttons-tipAndBtnContainer"
                  key={i}
                >
                  <div className="size-buttons-buttonContainer">
                    <button
                      // className={`size-buttons-size-button ${
                      //   getUserSize === size ? "selected-button" : ""
                      // }  size-buttons-size-button-default`}
                      className={`size-buttons-size-button ${
                        getSize === size ? "selected-button" : ""
                      }  size-buttons-size-button-default`}
                    >
                      <p
                        className={`size-buttons-unified-size ${
                          getSize === size ? "selected-button-text" : ""
                        }`}
                      >
                        {size}
                      </p>
                    </button>
                  </div>
                </div>
              ))}
              {sizeValidation && getSize === null && (
                <span style={{ color: "red", fontWeight: "600" }}>
                  Please select size
                </span>
              )}
            </div>
          </div>
        )}

        <div className="pdp-action-container pdp-fixed">
          {checkItemAdded ? (
            <div
              onClick={handleGoToBag}
              className="pdp-go-to-bag pdp-button pdp-flex pdp-center"
            >
              <Link href={"/cart"}>
                <p className="pdp-button-text">Go To Cart</p>
              </Link>
              <span className="svg-arrow">
                <BsFillHandbagFill />
              </span>
            </div>
          ) : (
            <div
              onClick={handleAddToBag}
              className="pdp-add-to-bag pdp-button pdp-flex pdp-center"
            >
              <span>
                <BsFillHandbagFill />
              </span>
              <p className="pdp-button-text">ADD TO BAG</p>
            </div>
          )}

          <div
            onClick={() => handleWishList(productId)}
            className="pdp-add-to-wishlist pdp-button pdp-flex pdp-center"
          >
            <span>
              {isWishlistAdded ? (
                <AiFillHeart className="heart-fill" title="added" />
              ) : (
                <AiOutlineHeart title="removed" />
              )}
            </span>
            <p className="button-text">
              {isWishlistAdded ? "WISHLISTED" : "WISHLIST"}
            </p>
          </div>
        </div>
      </div>

      <div className="pdp-describe">
        <div className="delivery-container">
          <div className="heading-container-delivery">
            <h4 className="heading">Delivery Options </h4>
            <span>
              <CiDeliveryTruck />
            </span>
          </div>
          <input
            type="text"
            className="pincode-input"
            placeholder="Enter pincode"
            name="pincode"
          />
          <input
            type="submit"
            className="pincode-check pincode-button"
            value="Check"
          />
          <p className="pincode-enterPincode-text">
            Please enter PIN code to check delivery time &amp; Pay on Delivery
            Availability
          </p>
          <p className="para">100% Original Products</p>
          <p className="para">Pay on delivery might be available</p>
          <p className="para">Easy 14 days returns and exchanges</p>
          <p className="para">Try & Buy might be available</p>
        </div>
        <div className="material-container">
          <h4 className="heading">Material & Care</h4>
          {material.map((material, i) => {
            return (
              <div key={i}>
                <p className="para">{material}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProductDescription;
