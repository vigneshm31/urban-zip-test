"use client";
import React, { useState, useEffect } from "react";
import CardList from "@/components/MyAccount/Products/Card/CardList";
import { TbShoppingBagX } from "react-icons/tb";
import Spinner from "@/components/Core/Spinner";
import ModalComponent from "@/components/Core/Modal";
import useBodyScrollLock from "@/hooks/useBodyScrollLock";

const ProductCards = ({filteredInputValues:dynamicFilters}) => {
  const [items, setItems] = useState(
    JSON.parse(localStorage.getItem("products")) || []
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Save items to local storage whenever items state changes
    localStorage.setItem("products", JSON.stringify(items));
  }, [items]);

  const deleteAll = () => {
    localStorage.removeItem("products");
    setItems([]);
  };
  const deleteItem = (itemId) => {
    const updatedItems = items.filter((item) => item.id !== itemId);
    setItems(updatedItems);
  };
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  useBodyScrollLock(isModalOpen);

  // Example filter function with dynamic user selection
// function filterProducts(filters) {
//   return items.filter(product => 
//     // (!filters.priceMin || product.price >= filters.priceMin) &&
//     // (!filters.priceMax || product.price <= filters.priceMax) &&
//     // (!filters.category || product.category === filters.category) &&
//     // (!filters.color || product.color === filters.color) &&
//     // (!filters.size || product.size.includes(filters.size))
//     (!filters.category || filters.category === 'allCategory' || product.category.toLowerCase() === filters.category) &&
//     // (!filters.priceMin || product.price >= filters.priceMin) &&
//     (!filters.priceMax || product.price <= filters.priceMax) 
//   );
// }
function filterProducts(filters) {
    return items.filter(product => {
    // Category filtering logic
    const isCategoryMatch = !filters.category || filters.category === 'allCategory' || product.category.toLowerCase() === filters.category;

    // Color filtering logic
    const isColorMatch = !filters.color || product.color === filters.color;

    // Size filtering logic
    const isSizeMatch = !filters.size || product.size.includes(filters.size);

    // Price filtering logic
    const isPriceMatch =
      (!filters.priceMin || Number(product.price) >= filters.priceMin) &&
      (!filters.priceMax || Number(product.price) <= filters.priceMax);

    // Combine all filtering conditions using logical AND
    return isCategoryMatch && isColorMatch && isSizeMatch && isPriceMatch;
  });
}


const filteredResults = filterProducts(dynamicFilters);

  return (
    <>
      <div className="products-card-list">
        <p className="heading">Products</p>
        <div className="list-heading">
          <p>Image</p>
          <p>Product Name</p>
          <p>Category</p>
          <p>Price</p>
          <p>Stock</p>
          <p>Sold</p>
          <p>Ratings</p>
          <p>Actions</p>
        </div>
        <div className="card-list">
          {filteredResults && filteredResults.length > 0 ? (
            filteredResults?.map((item, i) => {
              return (
                <CardList
                  key={i}
                  item={item}
                  index={i}
                  items={items}
                  setItems={setItems}
                  deleteItem={deleteItem}
                />
              );
            })
          ) : (
            //  : loading ? (
            //   <div>
            //     <Spinner />
            //   </div>
            // )
            <div className="no-product-found">
              <TbShoppingBagX />
              <span>Sorry, No products Found </span>
            </div>
          )}
        </div>
      </div>
      {items.length > 0 && (
        <div>
          <button  onClick={openModal} className="delete-btn"> Delete All</button>
         

          <ModalComponent isOpen={isModalOpen} closeModal={closeModal}>
        {/* UseBodyScrollLock to lock body scroll when the modal is open */}


        <p className="modal-heading">Are you sure, <span className="bold">delete All</span> products?</p>
        <div className="confirmation-container">
        <button onClick={closeModal} className="cancel-btn">cancel</button>
        <button onClick={()=>deleteAll() } className="delete-btn">Delete All</button>
        </div>
      </ModalComponent>
        </div>
      )}
    </>
  );
};

export default ProductCards;
