"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  MdCurrencyRupee,
  MdOutlinePercent,
  MdOutlineAddCircleOutline,
  MdOutlineDeleteOutline,
  MdEditNote,
} from "react-icons/md";
import { FaRegStar } from "react-icons/fa6";
import { AiOutlineStock, AiOutlineDelete } from "react-icons/ai";
import { GiReceiveMoney } from "react-icons/gi";
import { CiEdit } from "react-icons/ci";
import { useRouter } from 'next/navigation'

const CardList = ({ item, index, handleOpen, items, setItems }) => {
  const router = useRouter()
  const {
    id,
    name,
    productName,
    brand,
    category,
    price,
    stock,
    sold,
    image,
    imageUrl,
    totalRating,
    isActionOpen,
  } = item;
  const [open, setopen] = useState(false);
  const [formData,setFormData]=useState({})
  useEffect(() => {
    // Save items to local storage whenever items state changes
    localStorage.setItem("products", JSON.stringify(items));
  }, [items]);
  const deleteHandler = (selectedId) => {
    const updatedItems = items.filter((item) => item.id !== selectedId);
    setItems(updatedItems);
  };
  useEffect(() => {
    // Save items to local storage whenever items state changes
    localStorage.setItem("editData", JSON.stringify(formData));
  }, [formData]);
 const editHandler=(selectedId)=>{
  const selectedItem=items.find(item=>item.id===selectedId)
  if(selectedItem){
    setFormData(selectedItem)
  }
  router.push('/my-account/products/edit-products', { scroll: false })
 }
  return (
    <>
      <div className="card">
        <Image
          src={imageUrl ? imageUrl : image?.src}
          alt=""
          width={50}
          height={50}
        />
        <h4 className="name">{productName}</h4>
        <p>{category}</p>
        <p>
          <MdCurrencyRupee />
          {price}
        </p>
        <p>
          <AiOutlineStock />
          {stock}
        </p>
        <p>
          <GiReceiveMoney />
          {sold ?? "12"}
        </p>
        <p>
          <FaRegStar />
          {totalRating ?? "4.1"}
        </p>
        <div
          key={index}
          className="action-btn"
          onMouseEnter={() => setopen(!open)}
          onMouseLeave={() => setopen(!open)}
          // onClick={() => handleOpen(item)}
        >
          <BsThreeDotsVertical />
          {open ? (
            <div className="action-card">
              <button>
                <MdEditNote />
                <span onClick={() => editHandler(id)}>Edit</span>
              </button>
              <button>
                <MdOutlineDeleteOutline />
                <span onClick={() => deleteHandler(id)}>Delete</span>
              </button>
            </div>
          ) : null}
        </div>
      </div>
     
    </>
  );
};

export default CardList;
