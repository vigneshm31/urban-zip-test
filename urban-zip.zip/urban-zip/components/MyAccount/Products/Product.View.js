"use client";
import React, { useState } from "react";
import StickyFilter from "@/components/MyAccount/Products/StickyFilter/StickyFilter";
import ProductCards from "@/components/MyAccount/Products/Card/ProductCards";
import ProductTable from "@/components/MyAccount/Products/Table/ProductTable";

import Link from "next/link";
import { FaArrowRightToBracket } from "react-icons/fa6";
import Search from "./Search/Search";

const ProductView = ({
  productsDataFromDb,
  deleteProductFromDB,
  deleteAllProductsFromDB,
  totalCount
}) => {
  const productsData = JSON?.parse(productsDataFromDb);
  const [filteredInputValues, setfilteredInputValues] = useState({});
  return (
    <>
      <div className="page-header-container">
        <div className="heading">
          <h3>Products</h3>
        </div>

        <div className="view-store-link">
          <Link href={"/"}>
            View Your Store <FaArrowRightToBracket />
          </Link>
        </div>
      </div>
      <div className="page-main-container">
        {/* <StickyFilter
          setfilteredInputValues={setfilteredInputValues}
          filteredInputValues={filteredInputValues}
        /> */}
        {/* <ProductCards filteredInputValues={filteredInputValues} /> */}
        <Search placeholder={"Search for Products"} showAddBtn={true} />
        <ProductTable
          filteredInputValues={filteredInputValues}
          productsData={productsData}
          deleteProductFromDB={deleteProductFromDB}
          deleteAllProductsFromDB={deleteAllProductsFromDB}
          totalCount={totalCount}
        />
      </div>
    </>
  );
};
export default ProductView;
