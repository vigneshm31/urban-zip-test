"use client";
import React, { useState } from "react";
import { Button, Dropdown, message, Space, Tooltip, Select } from "antd";
import { DownOutlined, UserOutlined } from "@ant-design/icons";
import { MdOutlineKeyboardArrowDown } from "react-icons/md";
import { FaPerson, FaPersonDress } from "react-icons/fa6";
import { PiPersonSimpleBikeBold } from "react-icons/pi";
import { GiComb, GiLipstick } from "react-icons/gi";
import {
  MdCurrencyRupee,
  MdOutlinePercent,
  MdOutlineAddCircleOutline,
} from "react-icons/md";
import { IoChevronDown } from "react-icons/io5";
import { GoChecklist } from "react-icons/go";
import Link from "next/link";


const StickyFilter = ({filteredInputValues,setfilteredInputValues}) => {

  const handleChange = (value,filterType) => {
    var filterValues={ ...filteredInputValues }
    if(filterType==="category"){
        filterValues.category=value
    }else if(filterType==="price"){
      if (value === 'allPrice') {
        filterValues.priceMin = 0;
        filterValues.priceMax = 20000;
      }
      else if (value === 'upto500') {
        filterValues.priceMin = 0;
        filterValues.priceMax = 500;
      } else if (value === '500-1000') {
        filterValues.priceMin = 500;
        filterValues.priceMax = 1000;
      }else if (value === '1000-2000') {
        filterValues.priceMin = 1000;
        filterValues.priceMax = 2000;
      }else if (value === 'above2000') {
        filterValues.priceMin = 2000;
        filterValues.priceMax = 20000;
      }
    }
    setfilteredInputValues(filterValues)
   
  };
  const itemsCategory = [
    {
      label: "All",
      value:"allCategory",
      key: "1",
      icon: <GoChecklist />,
    },
    {
      label: "Men",
      value:"men",
      key: "2",
      icon: <FaPerson />,
    },
    {
      label: "Women",
      value:"women",
      key: "3",
      icon: <FaPersonDress />,
    },
    {
      label: "Kids",
      value:"kids",
      key: "4",
      icon: <PiPersonSimpleBikeBold />,
      //   danger: true,
    },
    {
      label: "Beauty",
      value:"beauty",
      key: "5",
      icon: <GiLipstick />,
      //   disabled: true,
    },
  ];
  const itemsPrice = [
    {
      label: "All",
      value:"allPrice",
      key: "1",
      icon: <MdCurrencyRupee />,
    },
    {
      label: "Upto 500",
      value:"upto500",
      key: "2",
      icon: <MdCurrencyRupee />,
    },
    {
      label: "500-1000",
      value:"500-1000",
      key: "3",
      icon: <MdCurrencyRupee />,
    },
    {
      label: "1000-2000",
      value:"1000-2000",
      key: "4",
      icon: <MdCurrencyRupee />,
      //   danger: true,
    },
    {
      label: "Above 2000",
      value:"above2000",
      key: "5",
      icon: <MdCurrencyRupee />,
      //   disabled: true,
    },
  ];
  const itemsPriceDiscount = [
    {
      label: "Upto 10%",
      value:"upto10",
      key: "1",
      icon: <MdOutlinePercent />,
    },
    {
      label: "10%-20%",
      value:"10-20",
      key: "2",
      icon: <MdOutlinePercent />,
    },
    {
      label: "30%-40%",
      value:"30-40",
      key: "3",
      icon: <MdOutlinePercent />,
      //   danger: true,
    },
    {
      label: "Above 50%",
      value:"above50",
      key: "4",
      icon: <MdOutlinePercent />,
      //   disabled: true,
    },
  ];
  const menuPropsCategory = {
    items: itemsCategory,
    // onClick: handleMenuClick,
  };
  const menuPropsPrice = {
    items: itemsPrice,
    // onClick: handleMenuClick,
  };
  const menuPropsDiscount = {
    items: itemsPriceDiscount,
    // onClick: handleMenuClick,
  };

  return (
    <div className="products-sticky-filter">
      {/* <Space size={20}>
        <div style={{ color: "green", fontWeight: "600", fontSize: "12px" }}>
          Filter by :
        </div>
        <Dropdown menu={menuPropsCategory} 
        // onClick={handleMenuClick}
        >
          <Button>
            <Space>
              Category
              <DownOutlined />
            </Space>
          </Button>
        </Dropdown>

        <Dropdown menu={menuPropsPrice}>
          <Button>
            <Space>
              Price
              <DownOutlined />
            </Space>
          </Button>
        </Dropdown>

        <Dropdown menu={menuPropsDiscount}>
          <Button>
            <Space>
              Discount Range
              <DownOutlined />
            </Space>
          </Button>
        </Dropdown>

       
      </Space> */}
      <div className="filter-container">
      <div style={{ color: "green", fontWeight: "600", fontSize: "12px" }}>
          Filter by :
        </div>
      <Select
        showSearch
        // defaultValue="lucy"
        style={{ width: 150 }}
        onChange={(e)=>handleChange(e,"category")}
        placeholder="Category"
        // optionFilterProp="children"
        // filterOption={(input, option) => (option?.label ?? '').toLowerCase().includes(input)}
        // // filterSort={(optionA, optionB) =>
        // //   (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
        // // }
        // options={itemsCategory}
        
      >
        {
          itemsCategory.map(((item,i)=>{
            return <Select.Option value={item.value} key={i}>{item.icon}<span>{item.label}</span></Select.Option>
          }))
        }
       </Select> 
       
      <Select
        showSearch
        // defaultValue="lucy"
        style={{ width: 150 }}
        onChange={(e)=>handleChange(e,"price")}
        placeholder="Price"
        // optionFilterProp="children"
        // filterOption={(input, option) => (option?.label ?? '').toLowerCase().includes(input)}
        // // filterSort={(optionA, optionB) =>
        // //   (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
        // // }
        // options={itemsCategory}
        
      >
        {
          itemsPrice.map(((item,i)=>{
            return <Select.Option value={item.value} key={i}>{item.icon}<span>{item.label}</span></Select.Option>
          }))
        }
       </Select> 

       
      <Select
        showSearch
        // defaultValue="lucy"
        style={{ width: 150 }}
        onChange={(e)=>handleChange(e,"discountRange")}
        placeholder="Discount"
        // optionFilterProp="children"
        // filterOption={(input, option) => (option?.label ?? '').toLowerCase().includes(input)}
        // // filterSort={(optionA, optionB) =>
        // //   (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
        // // }
        // options={itemsCategory}
        
      >
        {
          itemsPriceDiscount.map(((item,i)=>{
            return <Select.Option value={item.value} key={i}>{item.icon}<span>{item.label}</span></Select.Option>
          }))
        }
       </Select> 

       </div>
       <Link href={"/my-account/products/add-products"}>
      <div className="add-btn">
        <MdOutlineAddCircleOutline />
        <button>Add Product</button>
      </div>
      </Link>
    </div>
  );
};

export default StickyFilter;
