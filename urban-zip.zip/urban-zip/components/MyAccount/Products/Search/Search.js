"use client";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import React from "react";
import { CiSearch } from "react-icons/ci";
import { MdOutlineAddCircleOutline } from "react-icons/md";
import { useDebouncedCallback } from "use-debounce";

const Search = ({ placeholder, showAddBtn }) => {
  const searchParams = useSearchParams();
  const pathName = usePathname();
  const { replace } = useRouter();
  const handleChange = useDebouncedCallback((e) => {
    const params = new URLSearchParams(searchParams);
    params.set("page", 1);
    if (e.target.value) {
      e.target.value.length > 2 && params.set("q", e.target.value);
    } else {
      params.delete("q");
    }
    replace(`${pathName}?${params}`);
  }, 300);
  return (
    <>
      <div className="search-container">
        <div className="input-container">
          <CiSearch />
          <input
            type="text"
            onChange={handleChange}
            placeholder={placeholder}
          />
        </div>
        {showAddBtn && (
          <Link href={"/my-account/products/add-products"}>
            <div className="add-btn">
              <MdOutlineAddCircleOutline />
              <button>Add Product</button>
            </div>
          </Link>
        )}
      </div>
    </>
  );
};

export default Search;
