import React from 'react'
import galleryimg from "@/public/images/image-gallery.png";
import Image from "next/image";
import { MdOutlineFileUpload } from "react-icons/md";
const DragandDrop = () => {
  return (
    <div className="content">
    <p className="add-image-text">Add Images</p>
    <div className="upload-box">
      <div>
        <Image src={galleryimg.src} width={80} height={80} />
      </div>

      <div className="upload-box-text">
        <MdOutlineFileUpload />
        <span className="drop">Drop your files here . or</span>
        <span className="upload"> Browse </span>
      </div>
    </div>
  </div>
  )
}

export default DragandDrop