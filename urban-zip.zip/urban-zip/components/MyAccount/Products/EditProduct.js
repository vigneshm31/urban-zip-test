"use client";
import React, { useState, useEffect } from "react";
import { Formik, Field, Form, ErrorMessage, useFormik } from "formik";
import { Divider } from "antd";
import * as Yup from "yup";
import Input from "@/components/Input";
import DragandDrop from "./DragDrop/DragandDrop";
import { MdOutlineFileUpload } from "react-icons/md";
import galleryimg from "@/public/images/image-gallery.png";
import Image from "next/image";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

const EditProductLocal = ({ productToEditData, editProductFromDB }) => {
  const formData = JSON.parse(productToEditData);
  const router = useRouter();

  // const [formData, setFormData] = useState({});

  const initialValues = {
    imageUrl: formData.imageUrl,
    imageUrlFull: formData.imageUrlFull,
    productName: formData.productName,
    productId: formData.productId,
    brand: formData.brand,
    category: formData.category,
    fashionType: formData.fashionType,
    price: formData.price,
    mrp: formData.mrp,
    color: ["blue"],
    size: formData.size ?? "",
    returnOptions: formData.returnOptions ?? "",
    description: formData.description,
    stock: formData.stock,
    delivery: formData.delivery,
    id: formData._id,
  };
  const validationSchema = Yup.object({
    imageUrl: Yup.string().required(),
    imageUrlFull: Yup.string().required(),
    productName: Yup.string().required(),
    productId: Yup.string().required(),
    brand: Yup.string().trim().required().label("Brand"),
    category: Yup.string().required(),
    fashionType: Yup.string().required(),
    price: Yup.number().required().positive().integer(),
    mrp: Yup.number()
      .required()
      .positive()
      .integer()
      .label("MRP must be a number"),
    color: Yup.array().of(Yup.string()).label("Colors is Required"),
    size: Yup.array().required(),
    returnOptions: Yup.string().required(),
    description: Yup.string().max(50).required(),
    stock: Yup.number().required().positive().integer(),
    delivery: Yup.string().required(),
  });
  const onKeyDown = (keyEvent) => {
    if ((keyEvent.charCode || keyEvent.keyCode) === 13) {
      keyEvent.preventDefault();
    }
  };

  const categories = ["Men", "Women", "kids", "Beauty"];
  const fashionTypes = ["shirt", "t-shirts", "kurta", "Beauty"];
  const colors = ["green", "black", "yellow", "blue", "white", "red"];
  const sizes = ["s", "m", "l", "xl"];
  const sizesOptions = [
    { key: "small", value: "s" },
    { key: "medium", value: "m" },
    { key: "large", value: "l" },
    { key: "extralarge", value: "xl" },
  ];

  const isReturableOptions = [
    { key: "returnable", value: "returnable" },
    { key: "nonReturnable", value: "nonreturnable" },
    { key: "exchangeable", value: "exchangeable" },
  ];
  const onSubmit = (values, onSubmitProps) => {
    const {
      imageUrl,
      imageUrlFull,
      productName,
      productId,
      brand,
      category,
      fashionType,
      price,
      mrp,
      color,
      size,
      returnOptions,
      description,
      stock,
      delivery,
    } = values;

    let bodyToPass = {
      id: formData.id,
      timeStamp: new Date().toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
      imageUrl,
      imageUrlFull,
      productName,
      productId,
      brand,
      category,
      fashionType,
      price,
      mrp,
      color,
      size,
      returnOptions,
      description,
      stock,
      delivery,
      imageUrl: `${imageUrl}`,
      material: ["100% cotton", "Machine-wash", "Regular Fit"],
    };
    const findIndex = items.findIndex((obj) => obj.id === formData.id);
    if (findIndex !== -1) {
      const spliceArray = items.filter((item, index) => index !== findIndex);
      setItems([...spliceArray, (items[findIndex] = bodyToPass)]);
    }

    onSubmitProps.setSubmitting(false);
    onSubmitProps.resetForm();
    toast.success("Product Edited Successfully");
    router.push("/my-account/products");
    localStorage.removeItem("editData");
  };
  const handleEditProduct = editProductFromDB.bind(null, formData._id);

  return (
    <>
      <div className="add-product-container">
        <p className="heading">Edit Product</p>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
          enableReinitialize={true}
        >
          {({
            values,
            handleSubmit,
            isSubmitting,
            setFieldValue,
            touched,
            errors,
            isValid,
            dirty,
          }) => {
            return (
              <form action={handleEditProduct}>
                <div className="main-container">
                  <div className="image-upload left">
                    <Field
                      name="image"
                      component={DragandDrop}
                      accept="image/*"
                      margin="normal"
                      placeholder="Upload "
                    />
                    <Divider plain> or </Divider>
                    <div className="img-url">
                      <Field
                        as={Input}
                        name="imageUrl"
                        label="Image Url *"
                        type="text"
                        infoMessage="ImageUrl"
                        placeholder="Enter Image Url"
                      />
                      <Field
                        as={Input}
                        name="imageUrlFull"
                        label="Image Url Full *"
                        type="text"
                        infoMessage="Image Url Full"
                        placeholder="Enter Image Url Full"
                      />
                    </div>
                  </div>
                  <div className="product-form right">
                    <div className="product-form-fields">
                      <div className="form-container">
                        <Field
                          as={Input}
                          name="productName"
                          label="Product Name *"
                          type="text"
                          infoMessage="Product Name"
                          placeholder="Enter Product Name"
                        />
                        <div className="form-inner-flex">
                          <Field
                            as={Input}
                            name="productId"
                            label="Product ID *"
                            type="text"
                            infoMessage="Product ID"
                            placeholder="Enter Product ID"
                          />
                          <Field
                            as={Input}
                            name="brand"
                            label="Brand *"
                            type="text"
                            infoMessage="Brand"
                            placeholder="Enter Brand Name"
                          />
                        </div>
                        <div className="form-inner-flex">
                          <Field
                            as={Input}
                            name="category"
                            label="Category *"
                            type="select"
                            infoMessage="Category"
                            placeholder="Category"
                            onChange={(e) => {
                              setFieldValue("category", e.target.value);
                              // setFieldValue("subdomain", "");
                            }}
                          >
                            <option value="" disabled>
                              Category
                            </option>
                            {categories &&
                              categories.length &&
                              categories.map((category, index) => (
                                <option value={category} key={index}>
                                  {category}
                                </option>
                              ))}
                          </Field>

                          <Field
                            as={Input}
                            name="fashionType"
                            label="Fashion Type *"
                            type="select"
                            infoMessage="Fashion Type"
                            placeholder="Fashion Type"
                            onChange={(e) => {
                              setFieldValue("fashionType", e.target.value);
                              // setFieldValue("subdomain", "");
                            }}
                          >
                            <option value="" disabled>
                              Fashion
                            </option>
                            {fashionTypes &&
                              fashionTypes.length &&
                              fashionTypes.map((fashionType, index) => (
                                <option value={fashionType} key={index}>
                                  {fashionType}
                                </option>
                              ))}
                          </Field>
                        </div>

                        <div className="form-inner-flex">
                          <Field
                            as={Input}
                            name="price"
                            label="Price *"
                            type="text"
                            infoMessage="Price"
                            placeholder="Enter Price"
                          />
                          <Field
                            as={Input}
                            name="mrp"
                            label="MRP *"
                            type="text"
                            infoMessage="MRP"
                            placeholder="Enter mrp"
                          />
                        </div>
                        <Field
                          as={Input}
                          name="color"
                          label="Color *"
                          type="div"
                          infoMessage="Color"
                          placeholder="Select Color"
                        >
                          <div className="colors-container">
                            <div className="card-circle">
                              {colors.map((color, index) => {
                                return (
                                  <span
                                    key={index}
                                    style={{ background: `${color}` }}
                                    title={`${color}`}
                                  ></span>
                                );
                              })}
                            </div>
                          </div>
                        </Field>
                        <div className="form-inner-flex">
                          <div className="form-group radio-container">
                            <label className="form-label">Size Options *</label>
                            <div className="radio-div">
                              <Field name="size">
                                {({ field }) => {
                                  return sizesOptions?.map((option) => {
                                    return (
                                      <>
                                        <div className="radio-output">
                                          <input
                                            type="checkbox"
                                            id={option.value}
                                            {...field}
                                            value={option.value}
                                            checked={field.value.includes(
                                              option.value
                                            )}
                                          />
                                          <label
                                            htmlFor={option.value}
                                            className="form-label"
                                          >
                                            {option.key}
                                          </label>
                                        </div>
                                      </>
                                    );
                                  });
                                }}
                              </Field>
                              <ErrorMessage
                                name="size"
                                className="form-input-error"
                                component="div"
                              />
                            </div>
                          </div>
                          {/* radio button */}
                          <div className="form-group radio-container">
                            <label className="form-label">
                              Return Options *
                            </label>
                            <div className="radio-div">
                              <Field name="returnOptions">
                                {({ field }) => {
                                  return isReturableOptions?.map((option) => {
                                    return (
                                      <>
                                        <div className="radio-output">
                                          <input
                                            type="radio"
                                            id={option.value}
                                            {...field}
                                            value={option.value}
                                            checked={
                                              field.value === option.value
                                            }
                                          />
                                          <label
                                            htmlFor={option.value}
                                            className="form-label"
                                          >
                                            {option.key}
                                          </label>
                                        </div>
                                      </>
                                    );
                                  });
                                }}
                              </Field>
                              <ErrorMessage
                                name="returnOptions"
                                className="form-input-error"
                                component="div"
                              />
                            </div>
                          </div>
                        </div>
                        <Field
                          as={Input}
                          name="description"
                          label="Description *"
                          type="textarea"
                          infoMessage="Description"
                          placeholder="Description"
                        />
                        <div className="form-inner-flex">
                          <Field
                            as={Input}
                            name="stock"
                            label="Stock *"
                            type="text"
                            infoMessage="Stock"
                            placeholder="Enter Stock"
                          />
                          <Field
                            as={Input}
                            name="delivery"
                            label="Delivery *"
                            type="select"
                            infoMessage="Delivery"
                            placeholder="Delivery rates"
                            onChange={(e) => {
                              setFieldValue("delivery", e.target.value);
                            }}
                          >
                            <option value="" disabled>
                              Delivery Rates
                            </option>
                            {["Free", 29, 49, 99].map((category, index) => (
                              <option value={category} key={index}>
                                {category}
                              </option>
                            ))}
                          </Field>
                        </div>
                        <div className="submit-btn-container">
                          <div className="submit-btn">
                            {/* <button
                              type="submit"
                              className={`publish-btn ${
                                (!dirty || !isValid || isSubmitting) &&
                                "disabled"
                              }`}
                              onClick={handleSubmit}
                              infoMessage="Publish Product"
                              disabled={!dirty || !isValid || isSubmitting}
                            >
                              {isSubmitting
                                ? "Publishing..."
                                : "Publish Product"}
                            </button> */}
                            <button
                              type="submit"
                              className={`publish-btn`}
                              // onClick={handleSubmit}
                              infoMessage="Publish Product"
                            >
                              {isSubmitting
                                ? "Publishing..."
                                : "Publish Product"}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            );
          }}
        </Formik>
      </div>
    </>
  );
};

export default EditProductLocal;
