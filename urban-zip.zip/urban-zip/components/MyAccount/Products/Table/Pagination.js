"use client";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import React, { useState } from "react";

const Pagination = ({ totalCount }) => {
  const searchParams = useSearchParams();
  const pathName = usePathname();
  const { replace } = useRouter();
  const page = searchParams.get("page") || 1;
  const [rowsPage, setRowsPage] = useState(
    searchParams.get("rowsPerPage") || 5
  );

  const rowsPerPagee = searchParams.get("rowsPerPage") || 5;
  const ITEM_PER_PAGE = rowsPerPagee;
  const params = new URLSearchParams(searchParams);

  const hasPrev = ITEM_PER_PAGE * (parseInt(page) - 1) > 0;
  // const hasNext =
  //   ITEM_PER_PAGE * (parseInt(page) - 1) + ITEM_PER_PAGE < totalCount;
  let hasNext = false;

  if (page * ITEM_PER_PAGE <= totalCount) {
    hasNext = true;
  }

  const handleChangePage = (type) => {
    type === "prev"
      ? params.set("page", parseInt(page) - 1)
      : params.set("page", parseInt(page) + 1);
    replace(`${pathName}?${params}`);
  };
  const handleRowsPerPageChange = (e) => {
    setRowsPage(e.target.value);
    params.set("rowsPerPage", e.target.value);
    replace(`${pathName}?${params}`);
  };

  const rowsPerPage = [2, 5, 10];




  return (
    <>
      <div className="table-controls-container">
        <div className="rows-per-page">
          <p>Rows per page </p>
          <select
            id="rowsPerPage"
            value={rowsPage}
            onChange={handleRowsPerPageChange}
            className="custom-select"
          >
            {rowsPerPage.map((row) => (
              <option key={row} value={row}>
                {row}
              </option>
            ))}
          </select>
        </div>
        <div className="global-pagination-container">
          <ul>
            <li>
              <button
                disabled={!hasPrev}
                onClick={() => handleChangePage("prev")}
              >
                Prev
              </button>
            </li>
            <li>
              <button
                disabled={!hasNext}
                onClick={() => handleChangePage("next")}
              >
                Next
              </button>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default Pagination;
