"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  MdCurrencyRupee,
  MdOutlinePercent,
  MdOutlineAddCircleOutline,
  MdOutlineDeleteOutline,
  MdEditNote,
} from "react-icons/md";
import { FaRegStar } from "react-icons/fa6";
import { AiOutlineStock, AiOutlineDelete } from "react-icons/ai";
import { GiReceiveMoney } from "react-icons/gi";
import { CiEdit, CiCalendarDate } from "react-icons/ci";
import { useRouter } from "next/navigation";

const ProductTableRow = ({
  item,
  index,
  handleOpen,
  items,
  setItems,
  deleteByID,
}) => {
  const router = useRouter();
  const {
    _id,
    name,
    productName,
    productId,
    timeStamp,
    brand,
    category,
    price,
    stock,
    sold,
    image,
    imageUrl,
    totalRating,
    isActionOpen,
  } = item;

  const [open, setopen] = useState(false);

  const deleteHandler = (selectedId) => {
    deleteByID(selectedId);
  };
  const editHandler = (selectedId) => {
    const newProductId = productId.split(" ").join("");
    router.push(
      `/my-account/products/edit-products?productId=${newProductId}`,
      {
        scroll: false,
      }
    );
  };

  return (
    <>
      <tr className="table-tbody-tr">
        <td className="table-tbody-td">
          <Image
            src={imageUrl ? imageUrl : image?.src}
            alt=""
            width={50}
            height={50}
          />
        </td>
        <td className="table-tbody-td">{productName}</td>
        <td className="table-tbody-td ">
          <div className="td-icon">
            <CiCalendarDate />
            {timeStamp ?? "4.1"}
          </div>
        </td>
        <td className="table-tbody-td">{category}</td>
        <td className="table-tbody-td ">
          <div className="td-icon">
            <MdCurrencyRupee />
            {price}
          </div>
        </td>
        <td className="table-tbody-td">
          <div className="td-icon">
            <AiOutlineStock />
            {stock}
          </div>
        </td>
        <td className="table-tbody-td">
          <div className="td-icon">
            <GiReceiveMoney />
            {sold ?? "12"}
          </div>
        </td>

        <td className="table-tbody-td">
          <div
            key={index}
            className="action-btn"
            onMouseEnter={() => setopen(!open)}
            onMouseLeave={() => setopen(!open)}
            onClick={() => setopen(!open)}
          >
            <BsThreeDotsVertical />
            {open ? (
              <div className="action-card">
                <button>
                  <MdEditNote />
                  <span onClick={() => editHandler(_id)}>Edit</span>
                </button>
                <button>
                  <MdOutlineDeleteOutline />
                  <span onClick={() => deleteHandler(_id)}>Delete</span>
                </button>
              </div>
            ) : null}
          </div>
        </td>
      </tr>
    </>
  );
};

export default ProductTableRow;
