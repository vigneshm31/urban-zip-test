import React from 'react'

const TablePagination = () => {
  return (
    <div>TablePagination</div>
  )
}

export default TablePagination