"use client";
import React, { useState, useEffect, useCallback } from "react";
import { TbShoppingBagX } from "react-icons/tb";
import Spinner from "@/components/Core/Spinner";
import ModalComponent from "@/components/Core/Modal";
import useBodyScrollLock from "@/hooks/useBodyScrollLock";
import ProductTableRow from "@/components/MyAccount/Products/Table/ProductTableRow";
import Pagination from "@/components/MyAccount/Products/Table/Pagination";

const ProductTable = ({
  filteredInputValues: dynamicFilters,
  productsData,
  deleteProductFromDB,
  deleteAllProductsFromDB,
  totalCount
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [loading, setLoading] = useState(true);

  const deleteAll = () => {
    deleteAllProductsFromDB();
  };
  const deleteItem = (itemId) => {};
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  useBodyScrollLock(isModalOpen);

  const handlePageChange = (visibleData) => {};

  const tableHeading = [
    "Image",
    "Product Name",
    "Date",
    "Category",
    "Price",
    "Stock",
    "Sold",
    "Actions",
  ];
  return (
    <>
      <div className="products-table-container">
        <table className="table-tag">
          <thead className="table-thead">
            <tr className="table-thead-tr">
              {tableHeading.map((heading, i) => (
                <th key={i} className="table-thead-th">
                  {heading}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="table-tbody">
            {productsData && productsData.length > 0
              ? productsData?.map((item, i) => {
                  return (
                    <ProductTableRow
                      key={i}
                      item={item}
                      index={i}
                      deleteItem={deleteItem}
                      deleteByID={deleteProductFromDB}
                    />
                  );
                })
              : null}
          </tbody>
        </table>
        {productsData.length === 0 && (
          <div className="no-product-found">
            <TbShoppingBagX />
            <span>Sorry, No products Found </span>
          </div>
        )}
      </div>

      <Pagination data={productsData} onPageChange={handlePageChange}totalCount={totalCount} />

      <div className="delete-all-btn">
        {productsData.length > 0 && (
          <div>
            <button onClick={openModal} className="delete-btn">
              Delete All
            </button>

            <ModalComponent isOpen={isModalOpen} closeModal={closeModal}>
              {/* UseBodyScrollLock to lock body scroll when the modal is open */}

              <p className="modal-heading">
                Are you sure, <span className="bold">delete All</span> products?
              </p>
              <div className="confirmation-container">
                <button onClick={closeModal} className="cancel-btn">
                  cancel
                </button>
                <button onClick={() => deleteAll()} className="delete-btn">
                  Delete All
                </button>
              </div>
            </ModalComponent>
          </div>
        )}
      </div>
    </>
  );
};

export default ProductTable;
