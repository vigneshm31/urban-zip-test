"use client";
import React, { useState, useEffect } from "react";
import OrdersList from "./OrdersList";
import Link from "next/link";
import { FaArrowRightToBracket } from "react-icons/fa6";
import Search from "@/components/MyAccount/Products/Search/Search";
import Pagination from "@/components/MyAccount/Products/Table/Pagination";

const Orders = ({ orders, totalCount}) => {
  const tableHeading = [
    "Image",
    "Product Name",
    "Price",
    "Order Id",
    "Order Date",
    "Order Status",
    "Payment Type",
  ];
  const parsedOrders = JSON.parse(orders) || [];
  console.log(parsedOrders)
   return (
    <>
       <div className="page-header-container">
        <div className="heading">
          <h3>Orders</h3>
        </div>

        <div className="view-store-link">
          <Link href={"/"}>
            View Your Store <FaArrowRightToBracket />
          </Link>
        </div>
      </div>
      <div className="page-main-container">
      {/* <Search placeholder={"Search by OrderID"} showAddBtn={false} /> */}

      <div className="order-list-table">
        <table className="table-tag">
          <thead className="table-thead">
            <tr className="table-thead-tr">
              {tableHeading.map((heading, i) => (
                <th key={i} className="table-thead-th">
                  {heading}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="table-tbody">
          {parsedOrders.flatMap((user, userIndex) =>
              user.orders.map((order, orderIndex) => {
                return (
                    
                    <OrdersList
                      key={`${userIndex}-${orderIndex}`}
                      item={order}
                    //   user={user}
                    />
                  )
              })
            )}
          </tbody>
        </table>
      </div>
      {/* <Pagination totalCount={totalCount} /> */}

      </div>
    </>
  );
};

export default Orders;
