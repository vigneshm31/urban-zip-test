"use client";
import React from "react";
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";

const SalesReport = () => {
  const data = [
    {
      name: "Dec 1",
      sale: 1200,
      amt: 2400,
    },
    {
      name: "Dec 2",
      sale: 2500,
      amt: 2210,
    },
    {
      name: "Dec 3",
      sale: 1800,
      amt: 2290,
    },
    {
      name: "Dec 4",
      sale: 2780,
      amt: 2000,
    },
  ];

  return (
    <div className="sales-report">
      <p className="heading">Sales Report</p>
      <LineChart
        width={430}
        height={250}
        data={data}
      >
        <CartesianGrid strokeDasharray="5"  vertical={false}/>
        <XAxis dataKey="name"  axisLine={false} />
        <YAxis axisLine={false} />
        <Tooltip />
        {/* <Legend /> */}
        <Line type="monotone" dataKey="sale" stroke="#d9cb52"  strokeWidth="2" />
      </LineChart>
    </div>
  );
};

export default SalesReport;
