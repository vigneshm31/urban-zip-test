import React from 'react'
import TableView from "@/components/MyAccount/Dashboard/TableView"

const Table = () => {
  return (
    <div>
        <p className='heading'>Recent Orders</p>
        <TableView/>
    </div>
  )
}

export default Table