"use client";
import React, { useMemo, useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  flexRender,
  getPaginationRowModel,
  getSortedRowModel,
} from "@tanstack/react-table";
import { IoIosArrowDown } from "react-icons/io";

const TableView = () => {
  const allData = [
    {
      id: 121,
      date: "Aug 14,2023",
      productName:
        "new tshirt men balck color necknew tshirt men balck color neck",
      payment: "Paid",
      fullfillment: "In progress",
      total: 560,
    },
    {
      id: 131,
      date: "Aug 14,2023",
      productName:
        "new tshirt men balck color necknew tshirt men balck color neck",
      payment: "Paid",
      fullfillment: "In progress",
      total: 760,
    },
    {
      id: 141,
      date: "Aug 14,2023",
      productName:
        "new tshirt men balck color necknew tshirt men balck color neck",
      payment: "Paid",
      fullfillment: "In progress",
      total: 60,
    },
  ];
  const [sorting, setSorting] = useState([]);
  const data = useMemo(() => allData, []);
  const columns = [
    {
      header: "ID",
      accessorKey: "id",
      // accessorFn:"",
      //footer:"ID"
    },
    {
      header: "Date",
      accessorKey: "date",
    },
    {
      header: "Product",
      accessorKey: "productName",
    },

    {
      header: "Payment",
      accessorKey: "payment",
      cell: (info) => {
        return info.getValue().toUpperCase();
      }, // inorder to format a cell
    },
    {
      header: "Fullfillment",
      accessorKey: "fullfillment",
    },
    {
      header: "Total",
      accessorKey: "total",
    },
    {
      header: "Actions",
      cell: () => <span>...</span>,
    },
  ];

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    state: {
      sorting: sorting,
    },
    onSortingChange: setSorting,
  });
  return (
    <div className="table-container">
      <table className="table-tag">
        <thead className="table-thead">
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id} className="table-thead-tr">
              {headerGroup.headers.map((header) => (
                <th key={header.id} className="table-thead-th" onClick={header.column.getToggleSortingHandler()}>
                  {flexRender(
                    header.column.columnDef.header,
                    header.getContext
                  )}
                  {header.column.getIsSorted() ?null:<IoIosArrowDown/>}
                  {{asc:<IoIosArrowDown/>,desc:<IoIosArrowDown/>}[header.column.getIsSorted() ?? <IoIosArrowDown/>]}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody className="table-tbody">
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id} className="table-tbody-tr">
              {row.getVisibleCells().map((cell) => {
                return (
                  <td key={cell.id} className="table-tbody-td">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                );
              })}
              {/* <td>
                <button>...</button>
              </td> */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TableView;
