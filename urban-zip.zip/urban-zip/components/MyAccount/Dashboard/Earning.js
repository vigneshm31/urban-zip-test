"use client";
import React from "react";
import { PieChart, Pie, Cell, Label, Legend } from "recharts";

const Earning = () => {
  const data = [
    {
      name: "Revenue",
      value: 5400,
    },
    {
      name: "Profit",
      value: 2800,
    },
    {
      name: "Tax",
      value: 300,
    },
  ];
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];
  const CustomLabel = ({ viewBox, labelText, value }) => {
    const { cx, cy } = viewBox;
    return (
      <g>
        <text
          x={cx}
          y={cy}
          className="recharts-text recharts-label"
          textAnchor="middle"
          dominantBaseline="central"
          alignmentBaseline="middle"
          fontSize="15"
        >
          {labelText}
        </text>
        <text
          x={cx}
          y={cy + 20}
          className="recharts-text recharts-label"
          textAnchor="middle"
          dominantBaseline="central"
          alignmentBaseline="middle"
          fill="#0088FE"
          fontSize="26"
          fontWeight="600"
        >
          Rs.{value}
        </text>
      </g>
    );
  };
  const Bullet = ({ backgroundColor, size }) => {
    return (
      <div
        className="CirecleBullet"
        style={{
          backgroundColor,
          width: size,
          height: size,
        }}
      ></div>
    );
  };
  const CustomizedLegend = (props) => {
    const { payload } = props;
    return (
      <ul className="LegendList">
        {payload.map((entry, index) => (
          <li key={`item-${index}`}>
            <div className="BulletLabel">
              <Bullet backgroundColor={entry.payload.fill} size="10px" />
              <div className="BulletLabelText">{entry.value}</div>
            </div>
            <div>{entry.payload.value}</div>
          </li>
        ))}
      </ul>
    );
  };

  return (
    <>

        <div>
          <p className="heading">Earning</p>
          
          <PieChart width={200} height={200}>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              fill="#82ca9d"
            >
              {data.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
              <Label
                content={<CustomLabel labelText="Balance" value={2320} />}
                position="center"
              />
            </Pie>
            {/* <Legend content={<CustomizedLegend />} /> */}
          </PieChart>
        </div>

    </>
  );
};

export default Earning;
