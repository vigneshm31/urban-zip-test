"use client";
import React, { useState } from "react";
// import { useRouter } from 'next/navigation'
import { usePathname } from "next/navigation";
import Link from "next/link";
import { AiOutlineDashboard } from "react-icons/ai";
import { CiViewList } from "react-icons/ci";
import { MdOutlineSell } from "react-icons/md";
import { SlBookOpen } from "react-icons/sl";
import { LuListChecks } from "react-icons/lu";
import { FaShoppingBag, FaRegUser } from "react-icons/fa";
import { CgProfile } from "react-icons/cg";


import { FiLogOut, FiSettings } from "react-icons/fi";

const Sidebar = () => {
  const router = usePathname();

  const sideBarData = [
    {
      name: "Dashboard",
      path: "/my-account/dashboard",
      icon: true,
      iconurl: <AiOutlineDashboard />,
    },
    {
      name: "Products",
      path: "/my-account/products",
      icon: true,
      iconurl: <LuListChecks />,
    },
    {
      name: "Orders",
      path: "/my-account/orders",
      icon: true,
      iconurl: <SlBookOpen />,
    },
    {
      name: "Settings",
      path: "/my-account/settings",
      icon: true,
      iconurl: <FiSettings />,
    },
    {
      name: "Logout",
      path: "/",
      icon: true,
      iconurl: <FiLogOut />,
    },
  ];
  // const isActiveItem = (item) => {
  //   if (router?.includes("/dashboard") && item === "Dashboard") {
  //     return true;
  //   } else if (router?.includes("/products") && item === "Products") {
  //     return true;
  //   } else if (router?.includes("/orders") && item === "Orders") {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // };
  const isActiveItem = (item) => router?.includes(item.toLowerCase());

  return (
    <div>
      <div className="profile-container">
          <div className="profile">
            <CgProfile/>
            <div className="name">
            <p>Hello,</p>
            <span>Vignesh</span>
            </div>
            </div>
        </div>
      <ul className="list-container">

        
        {sideBarData &&
          sideBarData?.map((item, index) => {
            return (
              <Link href={item?.path} key={index}>
                <li
                  className={`list-item ${
                    isActiveItem(item?.name) && "active"    
                  } `}
                >
                  {item?.icon ? (
                    <span className="icon">{item.iconurl}</span>
                  ) : null}
                  <span className="list-text">{item?.name}</span>
                </li>
              </Link>
            );
          })}
      </ul>
    </div>
  );
};

export default Sidebar;
