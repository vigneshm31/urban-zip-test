import React from 'react'

const TextError = (props) => {

  return (
    <div className='error'>{props.errorText}</div>
  )
}

export default TextError