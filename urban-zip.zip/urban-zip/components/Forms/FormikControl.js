import React from "react";
import Input from "@/components/Forms/InputForm"

const FormikControl = (props) => {
  const { control, ...rest } = props;

  switch (control) {
    case "input":
      return <Input {...rest} />
    case "textarea":
      return <Input {...rest} />
    default:
      return null
  }


};

export default FormikControl
