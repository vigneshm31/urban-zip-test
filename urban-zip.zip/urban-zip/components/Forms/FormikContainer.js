import React from "react";
import { Formik, Form,Field } from "formik";
import * as Yup from "yup";
import FormikControl from "@/components/Forms/FormikControl";

const FormikContainer = (props) => {
  const initialValues = {
    email:""
  };
  const validationSchema = Yup.object({
    email:Yup.string().required()
  });
  const onSubmit = () => {
    alert("submitted!");
  };
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {formik => (
        <Form>
          <FormikControl
            control="input"
            type="text"
            label="Email"
            name="email"
          />
      <button type="submit">SubmitBtnText</button>
        </Form>
      )}
    </Formik>
  );
};

export default FormikContainer;
