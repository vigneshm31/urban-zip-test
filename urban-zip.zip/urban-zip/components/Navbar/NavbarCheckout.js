"use client";
import React from "react";
import Link from "next/link";
import { navBarCheckout as listMenu } from "@/public/tempdata/navbarData";
import { BsHandbag } from "react-icons/bs";
import { FaShoppingBag, FaRegUser } from "react-icons/fa";
import { AiOutlineUser } from "react-icons/ai";
import { PiUserCircleLight } from "react-icons/pi";
import { usePathname, useRouter } from "next/navigation";
import { FaThreads } from "react-icons/fa6";

import { AiOutlineMenu, AiOutlineHeart } from "react-icons/ai";
// import { useStateContext } from "context/GlobalState";

const NavbarCheckout = () => {
  // const {cartQuantity}=useStateContext()
  // const [showAccountLabel,setShowAccountLabel]=useState(false)
  const router = usePathname();
  const isActiveItem = (item) => {
    if (router?.includes("/cart") && item === "Bag") {
      return true;
    } else if (router?.includes("/checkout") && item === "Address") {
      return true;
    } else if (router?.includes("/payment") && item === "Payment") {
      return true;
    } else {
      return false;
    }
  };
  return (
    <div className="main-navbar-checkout-container">
      <div className="navbar-content">
        <div className="logo-container">
          <FaThreads />
          <Link href={"/"}>
            <h2 className="logo">
              <span className="first">Urban</span> Threads
            </h2>
          </Link>
        </div>
        <div className="navbar-menu-container">
          <ul className="checkout-steps">
            {listMenu?.map((menu, index) => (
              <React.Fragment key={index}>
                <Link href={menu.href}>
                  <li
                    className={`step step${index + 1} ${
                      isActiveItem(menu?.name) && "active"
                    }`}
                  >
                    {menu.name}
                  </li>
                </Link>

                {index < listMenu.length - 1 && (
                  <span className="divider-line"></span>
                )}
              </React.Fragment>
            ))}
          </ul>
        </div>

        <div className="navbar-user-sec"></div>
      </div>

      <div className="navbar-mobile-content">
        <div className="mobile-navbar-menu">
          <AiOutlineMenu />
        </div>
        <div className="logo-container">
          <FaShoppingBag />
          <h2 className="logo"> Ecom kart</h2>
        </div>

        <div className="navbar-user-sec">
          <div className="wishlist">
            <AiOutlineHeart />
          </div>

          <div className="cart">
            <Link href={"/cart"}>
              <BsHandbag />
              <span className="count-span">
                12
                {/* {cartQuantity} */}
              </span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
export default NavbarCheckout;
