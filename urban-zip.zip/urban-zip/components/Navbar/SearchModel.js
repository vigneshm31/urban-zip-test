import Link from "next/link";
import React, { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { debounce } from "lodash";
import { SearchKeywords } from "@/public/tempdata/searchKeywords";
import { usePathname, useRouter, useSearchParams } from "next/navigation";


const AccountModel = ({ session, userLogout }) => {
  const usePath = usePathname();
  const router = useRouter();
  const inputRef = useRef(null);
  const [searchText, setSearchText] = useState("");
  const [searchList, setSearchList] = useState([]);



  const searchParams = useSearchParams();
  const pathName = usePathname();
  const { replace } = useRouter();


  // const handleClick = (userSelectedWord) => {
    
  //   const params = new URLSearchParams(searchParams);
  //   console.log(params)

  //   params.set("page", 1);
  //   if (userSelectedWord &&  userSelectedWord.length > 2) {
  //   params.set("q", userSelectedWord);
  //   } else {
  //     params.delete("q");
  //   }
  //   replace(`${pathName}?${params}`);

  // };


  const handleClick = (userSelectedWord) => {
    if (userSelectedWord && userSelectedWord.length > 2) {
      // Navigate to the search page with the query parameter
      router.replace(`/search?q=${encodeURIComponent(userSelectedWord)}`);
    }
  };
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  useEffect(() => {
    if (searchText) {
      const searchData = SearchKeywords?.filter((txt) =>
        txt.toLowerCase().includes(searchText.toLowerCase())
      );
      setSearchList(searchData);
    } else {
      setSearchList([]);
    }
  }, [searchText]);

  const handleChange = debounce(async (value) => {
    setSearchText(value);
  }, 300);
  return (
    <div className="action-card">
      <div className="user-actions">
        <div className="search-container">
          <input
            ref={inputRef}
            placeholder="Search for products, brands and more"
            className="search-input"
            onChange={(e) => handleChange(e.target.value)}
          />
        </div>
      </div>
      <div className="user-related-datas">
        {searchList?.length > 0 &&
          searchList?.slice(0, 8).map((list, i) => {
            return (
              <>
                <p onClick={() => handleClick(list)}>{list}</p>
              </>
            );
          })}
      </div>
    </div>
  );
};

export default AccountModel;
