import React from "react";
import NavbarView from "@/components/Navbar/Navbar.view";
import { userLogout, getSession } from "@/utils/server/auth-actions";

const Navbar = async() => {
  const session= await getSession() 
  return (
    <>
      <NavbarView session={JSON.stringify(session)} userLogout={userLogout}/>     
    </>
  );
};

export default Navbar;
