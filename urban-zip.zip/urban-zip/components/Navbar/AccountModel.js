import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import React from "react";
import toast from "react-hot-toast";

const AccountModel = ({ session, userLogout }) => {
  const usePath = usePathname();
  const router = useRouter();

  const handleClick = (type) => {
    if (!session.isLoggedIn) {
      toast.error("Please login");
      router.push(`/user-auth?redirect=${encodeURIComponent(type)}`);
      return;
    } else {
      router.push(type);
    }
  };
  return (
    <div className="action-card">
      <div className="user-actions">
        <h4>Welcome</h4>
        <p>To access account and manage orders</p>
        {!session.isLoggedIn && (
          <Link href={"/user-auth"}>
            <button className="login-btn">LOGIN / SIGNUP</button>
          </Link>
        )}
      </div>
      <div className="user-related-datas">
        {session.isLoggedIn && session.isAdmin && (
          <Link href={"/my-account/products"}>
            <p>Admin</p>
          </Link>
        )}
        <p onClick={() => handleClick("orders")}>Orders</p>
        <p onClick={() => handleClick("wishlist")}>Wishlist</p>
        <p>Contact Us</p>
        <p>Track Order</p>
      </div>
    </div>
  );
};

export default AccountModel;
