"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { navBarMenu as listMenu } from "@/public/tempdata/navbarData";
import { BsHandbag } from "react-icons/bs";
import { FaShoppingBag, FaRegUser } from "react-icons/fa";
import { AiOutlineUser } from "react-icons/ai";
import { PiUserCircleLight } from "react-icons/pi";
import { usePathname, useRouter } from "next/navigation";
import { FaThreads } from "react-icons/fa6";
import { AiOutlineMenu, AiOutlineHeart, AiOutlineSearch } from "react-icons/ai";
import { useSelector } from "react-redux";
import AccountModel from "./AccountModel";
import SearchModel from "./SearchModel"
import { IoMdLogOut } from "react-icons/io";

const NavbarMain = ({ session, userLogout }) => {
  const [cartItems, setCartItems] = useState([]);
  const [open, setopen] = useState(false);
  const [openSearchModel, setOpenSearchModel] = useState(false);


  useEffect(() => {
    const existingCartData =
      JSON.parse(localStorage.getItem("listCartItems")) || [];
    setCartItems(existingCartData);
  }, []);
  const router = usePathname();
  const isActiveItem = (item) => {
    if (router?.includes("/men") && item === "Men") {
      return true;
    } else if (router?.includes("/women") && item === "Women") {
      return true;
    } else if (router?.includes("/kids") && item === "Kids") {
      return true;
    } else {
      return false;
    }
  };
 console.log(openSearchModel)
  return (
    <div className="main-navbar-container">
      <div className="navbar-content">
        <div className="logo-container">
          <FaThreads />
          <Link href={"/"}>
            <h2 className="logo">
              <span className="first">Urban</span> Threads
            </h2>
          </Link>
        </div>
        <div className="navbar-menu-container">
          <ul className="list-menu">
            {listMenu?.map((menu, i) => (
              <li className="list-content" key={i}>
                <Link
                  className={`list ${isActiveItem(menu?.name) && "active"}`}
                  href={`${menu.href}`}
                >
                  {menu.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="navbar-user-sec">
          <div className="overall-search">
          <div className="navbar-search-container"
           onClick={() => setOpenSearchModel(!openSearchModel)}             
            // onMouseLeave={() => setOpenSearchModel(!openSearchModel)}
            // onMouseEnter={() => setOpenSearchModel(!openSearchModel)}
>
            <AiOutlineSearch />

          </div>
          {openSearchModel && <SearchModel session={session} userLogout={userLogout} />}

          </div>
          <Link href={"/wishlist"}>
            <div className="wishlist">
              <AiOutlineHeart />
            </div>
          </Link>
          <Link href={"/cart"}>
            <div className="cart">
              <BsHandbag />
              <span className="count-span">{cartItems?.length}</span>
            </div>
          </Link>

          <div
            className="account"
            onMouseEnter={() => setopen(!open)}
            onMouseLeave={() => setopen(!open)}
            onClick={() => setopen(!open)}
          >
            <AiOutlineUser />
            {open && <AccountModel session={session} userLogout={userLogout} />}
          </div>
          {session.isLoggedIn && (
            <div className="logout">
              <form action={userLogout}>
                <button>
                  <IoMdLogOut />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      <div className="navbar-mobile-content">
        <div className="mobile-navbar-menu">
          <AiOutlineMenu />
        </div>
        <div className="logo-container">
          <FaThreads />
          <Link href={"/"}>
            <h2 className="logo">
              <span className="first">Urban</span> Threads
            </h2>
          </Link>
        </div>

        <div className="navbar-user-sec">
          <div className="wishlist">
            <AiOutlineHeart />
          </div>

          <div className="cart">
            <Link href={"/cart"}>
              <BsHandbag />
              <span className="count-span">
                12
                {/* {cartQuantity} */}
              </span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
export default NavbarMain;
