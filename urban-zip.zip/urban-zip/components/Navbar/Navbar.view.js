"use client";
import React from "react";
import NavbarMain from "@/components/Navbar/NavbarMain";
import NavbarCheckout from "@/components/Navbar/NavbarCheckout";
import { usePathname, useRouter } from "next/navigation";

const NavbarView = ({ session, userLogout }) => {
  const parsedSession = JSON.parse(session);
  const router = usePathname();
  const isCheckoutPage =
    router?.includes("/cart") ||
    router?.includes("/checkout") ||
    router?.includes("/payment");
  const isAccountsPage = router?.includes("/my-account");
  return (
    <>
      {!isCheckoutPage && !isAccountsPage && (
        <NavbarMain session={parsedSession} userLogout={userLogout} />
      )}
      {isCheckoutPage && <NavbarCheckout />}
      {isAccountsPage && null}
    </>
  );
};

export default NavbarView;
