import { formatDate } from "@/utils";
import Image from "next/image";
import React, { useState, useEffect } from "react";

const OrdersList = ({ item,productItems }) => {
  const {items, orderId, orderStatus, paymentMethod, totalAmount, updatedAt, } =
    item;

    const { productId, selectedSize, quantity, productName, productImage } = items[0]; // Assuming there is only one item in the items array

  const [errorImage, setErrorImage] = useState(false);
    const handleError = () => {
    setErrorImage(true);
  };
 
  return (
    <tr className="table-tbody-tr">
      <td className="table-tbody-td">
        <Image
          src={productImage}
          alt={productName}
          width={50}
          height={50}
          // onError={handleError}
        />
      </td>
      <td className="table-tbody-td">{productName}</td>
      <td className="table-tbody-td">Rs {totalAmount}</td>
      <td className="table-tbody-td">ORD- {orderId}</td>
      <td className="table-tbody-td">{formatDate(updatedAt)}</td>
      <td className="table-tbody-td">{"Order-confirmed"}</td>

    </tr>
  );
};

export default OrdersList;
