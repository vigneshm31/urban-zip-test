"use client";
import React, { useState, useEffect } from "react";
import OrdersList from "./OrdersList";

const Orders = ({ orders, getProductByProductIdsForCartFromDB }) => {
  const tableHeading = [
    "Image",
    "Product Name",
    "Price",
    "Order Id",
    "Order Date",
    "Order Status",
  ];
  const parsedOrders = JSON.parse(orders) || [];
 
 
  return (
    <>
      <div className="order-list-table">
        <table className="table-tag">
          <thead className="table-thead">
            <tr className="table-thead-tr">
              {tableHeading.map((heading, i) => (
                <th key={i} className="table-thead-th">
                  {heading}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="table-tbody">
            {parsedOrders?.map((item, i) => {
             
              return (
                <OrdersList
                  key={i}
                  item={item}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Orders;
