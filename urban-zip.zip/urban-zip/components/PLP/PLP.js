"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import Filters from "@/components/Filters/Filters";
import ProductTile from "@/components/PLP/ProductTile";
import Spinner from "@/components/Core/Spinner";
import { Pagination } from "@/components/Pagination/Pagination";
import { FiMapPin } from "react-icons/fi";
import { getUserData } from "@/utils";

const PLP = ({ tripDataLength, products, urlCategory, getFilterProducts }) => {
  const getProducts = JSON.parse(products);
  const productsDataLength = getProducts.length;
  const [filteredData, setFilteredData] = useState([]);
  const [selectedFilters, setSelectedFilters] = useState({
    brand: [],
    price: [],
    rating: [],
  });
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);

  const [userData, setUserData] = useState(null);

  const itemsPerPage = 4;
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const totalPages = Math.ceil(productsDataLength / itemsPerPage);

  // Function to fetch data based on filters and update URL
  const fetchData = async () => {
    const skip = (currentPage - 1) * itemsPerPage;

    // const getFilterData = await getFilterProducts.bind(null, selectedFilters, skip, itemsPerPage)();

    try {
      // const response = await getFilterData();
      const getFilterData = await getFilterProducts.bind(
        null,
        selectedFilters,
        urlCategory,
        skip,
        itemsPerPage
      )();

      setLoading(false);
      setFilteredData(getFilterData);
    } catch (error) {
      console.error(error);
    }
  };

  // Fetch data initially and on filter changes using useEffect
  useEffect(() => {
    fetchData();
  }, [selectedFilters, currentPage]); // Re-run useEffect on changes to selectedFilters

  const pagination = [];
  for (let i = 1; i <= totalPages; i++) {
    pagination.push(
      <button
        key={i}
        onClick={() => handlePageChange(i)}
        className={currentPage === i ? "active" : ""}
      >
        {i}
      </button>
    );
  }
  useEffect(() => {
    const fetchData = async () => {
      try {
        const userData = await getUserData();
        setUserData(userData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      {loading && <Spinner />}
      {!loading && (
        <>
          <div className="plp-container">
            <div className="filter-container">
              <Filters
                getFilterProducts={getFilterProducts}
                setFilteredData={setFilteredData}
                loading={loading}
                setLoading={setLoading}
                selectedFilters={selectedFilters}
                setSelectedFilters={setSelectedFilters}
              />
            </div>
            <div className="plp-listing">
              {/* <p className="plp-title">Showing <span>{urlCategory}</span> Results</p> */}
              <div className="listing-cards-container">
                {filteredData?.length > 0 &&
                  filteredData
                    ?.slice(
                      (currentPage - 1) * itemsPerPage,
                      itemsPerPage * currentPage
                    )
                    .map((item, i) => {
                      return (
                        <Link href={`/products/${item?.productId}`} key={i}>
                          <ProductTile item={item} userData={userData} />
                        </Link>
                      );
                    })}
              </div>
              {filteredData.length > 0 &&
                filteredData.length > itemsPerPage && (
                  <Pagination
                    pagination={pagination}
                    handlePageChange={handlePageChange}
                    currentPage={currentPage}
                    totalPages={totalPages}
                  />
                )}
              {filteredData?.length === 0 && (
                <div className="no-product-found">
                  <FiMapPin />
                  <span>Sorry, No Data Found </span>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default PLP;
