import React from "react";
// import photo from "@/public/images/hero.webp";
import photo from "@/public/images/home1.png";


const HeroBanner = () => {
  return (
    <div className="jumbotron">
      <div className="jumbotron-left">
        <h1>
          <span> Lowest Prices</span>
          <span className="span-ext">Best Quality Shopping</span>
        </h1>

        <div className="extra">
          <div className="one">
            <img src="https://images.meesho.com/images/pow/freeDelivery.svg" alt="" />
            <span>Free Delivery</span>
          </div>
          <div className="one">
            <img src="https://images.meesho.com/images/pow/cod.svg" alt="" />
            <span>Cash on Delivery</span>
          </div>
          <div className="one">
            <img src="	https://images.meesho.com/images/pow/easyReturns.svg" alt="" />
            <span>Easy Returns</span>
          </div>
        </div>
        <div className="jumbotron-button">
        <button >Live Now</button>
        </div>
      </div>
      <div className="jumbotron-right">
        <img src={photo.src} alt="img" className="jumbotron-image" />
      </div>
    </div>
  );
};

export default HeroBanner;
