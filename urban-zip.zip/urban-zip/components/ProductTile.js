"use client"
import React from "react";
import { BsCurrencyRupee } from "react-icons/bs";
import { AiOutlineHeart, AiFillHeart } from "react-icons/ai";
import { TiStarFullOutline } from "react-icons/ti";
import { GrClose } from "react-icons/gr";
import { usePathname, useRouter } from "next/navigation";


const ProductTile = (props) => {
  const {
    id,
    brand,
    productID,
    price,
    image,
    color,
    size,
    deliveryType,
    mrp,
    rating,
    totalRating,
    imageUrl,
    isWhishListPage=false
  }=props
  const router = usePathname();


  let discountPercent = 0;

  const discountCalculator = (price, mrp) => {

    const sellingPercent = (price / mrp) * 100;
    discountPercent = 100 - sellingPercent;

    return Math.round(discountPercent);
  };
  const kFormatter = (num) => {
    return Math.abs(num) > 999
      ? Math.sign(num) * (Math.abs(num) / 1000).toFixed(1) + "k"
      : Math.sign(num) * Math.abs(num);
  };
  const handleRemove=(e)=>{
      e.stopPropagation()
      // removeFromWishList(id)
  }
  
  return (
    <div className="card">
      <div className="card-image">
        {/* {
          isWhishListPage && (
            <span
            onClick={handleRemove}
            className="close-icon" title="delete" ><GrClose/></span>
          )
        } */}
        <img src={imageUrl ? imageUrl :image.src} alt="" />
      </div>
      <div className="card-content">
        <div className="card-heading-wishlist">
          <h3>{brand}</h3>
          {/* <div >
            {isWhishList ? (
              <AiFillHeart className="heart-fill" title="added" />
            ) : (
              <AiOutlineHeart title="removed" />
            )}
          </div> */}
              <AiFillHeart className="heart-filled" title="added" />
        </div>

        <div className="sub-content">
          <div className="price">
            <BsCurrencyRupee />
            <p>{price}</p>
            <span className="pdp-mrp">
              <span className="pdp-mrp-price">
                <BsCurrencyRupee />
                <p>{mrp}</p>
              </span>
            </span>
            <div className="pdp-mrp-discount">
              <p>&#40;</p>
              <p> {discountCalculator(price, mrp)} </p>
              <p>&#37;</p>
              <p>OFF</p>
              <p> &#41;</p>
            </div>
          </div>
          <div className="index-overallRatingContainer">
            <div className="index-overallRating">
          <div className="rating-num">{rating ?? "4.1"}</div>
            <span className="rating-star">
              <TiStarFullOutline />
            </span>
            <div className="index-separator">|</div>
            <div className="index-ratingsCount">
              <span className="total-num">{kFormatter(totalRating ?? "3000")}</span>
              <span className="total-text">Ratings</span>
            </div>
            </div>
          <div className="chip">{deliveryType ?? "Free Delivery"}</div>
          </div>
          {size && (
            <div className="size-container">
              <p>size:</p>
              {size.map((size,i) => (
                <div key={i}>
                <span>{size}</span>
                </div>
              ))}
            </div>
          )}
        </div>
        {
         router&& router?.includes("/cart") || router?.includes("/wishlist") && <div className="card-button">
          <button>Add to Bag</button>
        </div>
        }     
      </div>
    </div>
  );
};

export default ProductTile;
