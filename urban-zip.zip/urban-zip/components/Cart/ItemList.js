"use client";
import React, { useState, useEffect } from "react";
import { BsCurrencyRupee } from "react-icons/bs";
import { GrClose, GrAdd, GrFormSubtract } from "react-icons/gr";
import ModalComponent from "@/components/Core/Modal";
import useBodyScrollLock from "@/hooks/useBodyScrollLock";
import Link from "next/link";

const ItemList = ({
  decreaseCartQuantity,
  increaseCartQuantity,
  removeFromCart,
  itemSizeQuantity,
  index,
  ...item
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { id, brand, productName, productId, imageUrl, price, mrp, size } =
    item;

  let discountPercent = 0;
  const discountCalculator = (price, mrp) => {
    const sellingPercent = (price / mrp) * 100;
    discountPercent = 100 - sellingPercent;

    return Math.round(discountPercent);
  };
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  useBodyScrollLock(isModalOpen);
  return (
    <>
      <div className="items-container">
        <Link href={`/products/${productId}`}>
          <div className="item-img">
            <img src={imageUrl} alt="" />
          </div>
        </Link>
        <div className="item-content">
          <div className="item-title">
            <p className="item-brand">{brand}</p>
            <p className="item-description">{productName}</p>
          </div>
          <div className="item-size-quanity-container">
            {size && (
              <div className="item-size">
                <p>Size:</p>
                <button>
                  {itemSizeQuantity && itemSizeQuantity[index]
                    ? itemSizeQuantity[index][0]
                    : null}
                </button>
              </div>
            )}
            <div className="item-select-qty">
              <div
                className={`item-qty ${
                  itemSizeQuantity && itemSizeQuantity[index]
                    ? itemSizeQuantity[index][1] === 1
                      ? "disabled-qty"
                      : ""
                    : null
                }`}
                onClick={() => decreaseCartQuantity(productId)}
              >
                <GrFormSubtract />
              </div>
              <div className="item-qty count">
                {itemSizeQuantity && itemSizeQuantity[index]
                  ? itemSizeQuantity[index][1]
                  : null}
              </div>
              <div
                className="item-qty"
                onClick={() => increaseCartQuantity(productId)}
              >
                <GrAdd />
              </div>
            </div>
          </div>
          <div className="pdp-discount-container">
            <div className="pdp-price">
              <BsCurrencyRupee />
              <p className="pdp-sell-price">{price}</p>
              <p className="pdp-mrp">
                <span>MRP</span>
                <span className="pdp-mrp-price">
                  <BsCurrencyRupee />
                  <p>{mrp}</p>
                </span>
              </p>
              <div className="pdp-mrp-discount">
                <p>&#40;</p>
                <p> {discountCalculator(price, mrp)} </p>
                <p>&#37;</p>
                <p>OFF</p>
                <p> &#41;</p>
              </div>
            </div>
            <div>
              <p className="extra-info">Inclusive of all taxes</p>
            </div>
          </div>
        </div>

        <div className="item-delete" onClick={() => openModal()}>
          <span title="Delete">
            <GrClose />
          </span>
        </div>
        <ModalComponent isOpen={isModalOpen} closeModal={closeModal}>
          <p className="modal-heading">
            Are you sure, <span className="bold">delete </span> this product?
          </p>
          <div className="confirmation-container">
            <button onClick={closeModal} className="cancel-btn">
              cancel
            </button>
            <button
              onClick={() => {
                removeFromCart(productId);
                closeModal();
              }}
              className="delete-btn"
            >
              Delete
            </button>
          </div>
        </ModalComponent>
      </div>
    </>
  );
};

export default ItemList;
