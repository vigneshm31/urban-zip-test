"use client";
import React, { useState, useEffect } from "react";
import ItemList from "@/components/Cart/ItemList";
import PriceList from "@/components/Cart/PriceList";
import Spinner from "@/components/Core/Spinner";
import ProductTile from "@/components/ProductTile";
import Link from "next/link";
import useBodyScrollLock from "@/hooks/useBodyScrollLock";
import { allData as data } from "@/public/tempdata/index";
import { unstable_noStore as noStore, revalidatePath } from "next/cache";
import { useRouter } from 'next/navigation';
 



const CartComponent = ({ getProductByProductIdsForCartFromDB }) => {
  const [cartProductItems, setCartProductItems] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const router = useRouter();
  const fetchData = async () => {
    const existingCartData =
      JSON.parse(localStorage.getItem("listCartItems")) || [];

    setCartItems(existingCartData);
    if (existingCartData?.length) {
      const cartItemsIDs = existingCartData?.map((item) => item.productId);
      if (cartItemsIDs) {
        const getCartItemsFromDB =
          await getProductByProductIdsForCartFromDB.bind(null, cartItemsIDs);
        try {
          const response =await getCartItemsFromDB();
          setCartProductItems(response);
        } catch (error) {
          console.log(error);
        }
      }
    }
    setLoading(false);

  };

  useEffect(() => {
    // const existingProductData =
    //   JSON.parse(localStorage.getItem("products")) || [];

    // const existingCartData =
    //   JSON.parse(localStorage.getItem("listCartItems")) || [];

    // setLoading(false);
    // setCartItems(existingCartData);
    // if (existingCartData?.length) {
    //   const cartItemsIDs = existingCartData?.map((item) => item.productId);
    //   if (cartItemsIDs) {
    //     const cartData = existingProductData?.filter((product) =>
    //       cartItemsIDs?.includes(product?.id)
    //     );
    //     setCartProductItems(cartData);
    //   }
    // }
    fetchData();
  }, []);
  const increaseCartQuantity = (itemid) => {
    const updateCartQuantity = cartItems.map((item) => {
      if (item.productId === itemid) {
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });
    setCartItems(updateCartQuantity);
    updateLocalStorage(updateCartQuantity);
  };

  const decreaseCartQuantity = (itemid) => {
    const updateCartQuantity = cartItems.map((item) => {
      if (item.productId === itemid && item.quantity > 1) {
        return { ...item, quantity: item.quantity - 1 };
      }
      return item;
    });
    setCartItems(updateCartQuantity);
    updateLocalStorage(updateCartQuantity);
  };

  const removeFromCart = (itemid) => {
    const updateCartItems = cartItems.filter(
      (item) => item.productId !== itemid
    );
    setCartItems(updateCartItems);
    updateLocalStorage(updateCartItems);
    router.push("/cart");

  };
  const updateLocalStorage = (updatedCartItems) => {
    // Update localStorage with the updated cart items
    localStorage.setItem("listCartItems", JSON.stringify(updatedCartItems));
  };

  const itemSizeQuantity = cartItems.map((item) => {
    const itemListData = [item.selectedSize, item.quantity];
    return itemListData;
  });


  let sellingTotalPrice = 0;
  sellingTotalPrice = cartItems?.reduce((total, cartItem) => {
    //Taking the item from all data
    const item = cartProductItems?.find(
      (item) => item?.productId === cartItem?.productId
    );
    return total + (item?.price || 0) * cartItem.quantity;
  }, 0);

  let mrpTotalPrice = 0;
  mrpTotalPrice = cartItems?.reduce((total, cartItem) => {
    //Taking the item from all data
    const item = cartProductItems?.find(
      (item) => item?.productId === cartItem?.productId
    );
    return total + (item?.mrp || 0) * cartItem.quantity;
  }, 0);

  const discountAmount = mrpTotalPrice - sellingTotalPrice;

  const convenienceFees = 0;

  useEffect(()=>{
    const totalCartPriceList={
      mrpTotalPrice,
      discountAmount,
      convenienceFees,
      sellingTotalPrice

    }
      localStorage.setItem("totalCartPriceList",JSON.stringify(totalCartPriceList))
  },[mrpTotalPrice,sellingTotalPrice,convenienceFees,discountAmount])


  return (
    <>
      <div className="flex-container">
        <div className="item-list-container">
          <h2 className="heading">ITEMS</h2>
          <div className="horizontal-separator"></div>

          {cartItems.length && cartProductItems?.length > 0 ? (
            cartProductItems?.map((item, index) => (
              <ItemList
                {...item}
                increaseCartQuantity={increaseCartQuantity}
                decreaseCartQuantity={decreaseCartQuantity}
                removeFromCart={removeFromCart}
                itemSizeQuantity={itemSizeQuantity}
                index={index}
                key={index}
              />
            ))
          ) : loading ? (
            <Spinner />
          ) : (
            <p>No cart items </p>
          )}
        </div>
        <div className="vertical-separator"></div>
        <div className="price-list-container">
          <PriceList
            // cartProductItems={cartProductItems}
            // cartItems={cartItems}

            sellingTotalPrice={sellingTotalPrice}
            mrpTotalPrice={mrpTotalPrice}
            convenienceFees={convenienceFees}
            discountAmount={discountAmount}

          />
        </div>
      </div>
      <div className="cart-you-may-like-container bestselling-container">
        <div className="heading-container">
          <h2 className="heading">You may also Like</h2>
          <p className="para"> Best Products at greater discounts !</p>
        </div>
        <div className="listing-cards-container">
          {data?.length > 0 &&
            data?.map((item, i) => {
              return (
                <Link href={`/${item?.category}/${item?.id}`} key={i}>
                  <ProductTile
                    id={item.id}
                    brand={item.brand}
                    color={item.color}
                    size={item.size}
                    image={item.image}
                    price={item.price}
                    deliveryType={item.deliveryType}
                    isWhishList={item.isWhishList}
                    item={item}
                    mrp={item.mrp}
                    rating={item.rating}
                    totalRating={item.totalRating}
                    {...item}
                  />
                </Link>
              );
            })}
        </div>
      </div>
    </>
  );
};

export default CartComponent;
