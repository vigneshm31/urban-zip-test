"use client";
import React, { useEffect } from "react";
import Link from "next/link";
import { BiRupee } from "react-icons/bi";
import { formatCurrency } from "@/utils/index";
import { allData as data } from "@/public/tempdata/index";
import { usePathname, useRouter } from "next/navigation";
import { getSession } from "@/utils/server/auth-actions";
import toast from "react-hot-toast";

const PriceList = ({
  cartProductItems,
  cartItems,
  sellingTotalPrice,
  mrpTotalPrice,
  convenienceFees,
  discountAmount,
  addresses,
}) => {
  // let sellingTotalPrice = 0;
  // sellingTotalPrice = cartItems?.reduce((total, cartItem) => {
  //   //Taking the item from all data
  //   const item = cartProductItems?.find(
  //     (item) => item?.productId === cartItem?.productId
  //   );
  //   return total + (item?.price || 0) * cartItem.quantity;
  // }, 0);

  // let mrpTotalPrice = 0;
  // mrpTotalPrice = cartItems?.reduce((total, cartItem) => {
  //   //Taking the item from all data
  //   const item = cartProductItems?.find(
  //     (item) => item?.productId === cartItem?.productId
  //   );
  //   return total + (item?.mrp || 0) * cartItem.quantity;
  // }, 0);

  // const discountAmount = mrpTotalPrice - sellingTotalPrice;

  // const convenienceFees = 0;
  const router = useRouter();
  const usePath = usePathname();

  const handleRedirect = async () => {
    const session = await getSession();

    if (session?.isLoggedIn) {
      usePath.includes("/cart")
        ? router.push("/checkout")
        : router.push("/payment");
    } else {
      toast.error("Please login to Continue");
      // router.push("/user-auth")
      router.push(`/user-auth?redirect=${encodeURIComponent(usePath)}`);
    }
  };
  const isPaymentPage = usePath.includes("/payment");
  const isCheckoutPage = usePath.includes("/checkout");

  const addressAvailable = isCheckoutPage && addresses && JSON?.parse(addresses).length>0 ?true  : false;
  return (
    <div className="price-container">
      <p className="heading">TOTAL SUMMARY</p>

      <div className="summary-list">
        <div className="lists">
          <span>Total MRP</span>
          <span className="rs-price">
            <BiRupee /> {formatCurrency(mrpTotalPrice)}
          </span>
        </div>
        <div className="lists">
          <span>Discount on MRP</span>
          <span className="rs-price finalrs">
            <BiRupee />-{formatCurrency(discountAmount)}
          </span>
        </div>
        <div className="lists">
          <span>Convenience Fee</span>
          <span className="rs-price">
            {" "}
            <BiRupee />
            {formatCurrency(convenienceFees)}
          </span>
        </div>
        <div className="lists finalprice">
          <span>Total Amount</span>
          <span className="rs-price ">
            <BiRupee />
            {formatCurrency(sellingTotalPrice)}
          </span>
        </div>
        {sellingTotalPrice > 0 &&
          !isPaymentPage &&
           (
            // <Link href={"/checkout"}>
            <div onClick={handleRedirect} className="checkout-btn">
              {
                usePath.includes("/cart") ? <button>CONTINUE TO CHECKOUT</button>:
                addressAvailable ?<button>CONTINUE TO PAYMENT</button >:<button disabled>ADD ADDRESS TO CONTINUE</button>
              }
              
            </div>
            // </Link>
          )}
      </div>
    </div>
  );
};

export default PriceList;
