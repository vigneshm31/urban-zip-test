import Link from "next/link";
import React from "react";

const Success = () => {
  return (
    <div className="container">
      <div class="svg-container">
        <svg
          class="ft-green-tick"
          xmlns="http://www.w3.org/2000/svg"
          height="60"
          width="60"
          viewBox="0 0 48 48"
          aria-hidden="true"
        >
          <circle class="circle" fill="#5bb543" cx="24" cy="24" r="22" />
          <path
            class="tick"
            fill="none"
            stroke="#FFF"
            stroke-width="6"
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-miterlimit="10"
            d="M14 27l5.917 4.917L34 17"
          />
        </svg>
      </div>
      <p>Thanks for Ordering!</p>

      <div className="btn-container">
      <Link href={"/orders"}>
        <button className="btn1">Order Details</button>
        </Link>
        <Link href={"/"}>
        <button className="btn2" >Continue Shopping</button>
        </Link>
      </div>


    </div>
  );
};

export default Success;
