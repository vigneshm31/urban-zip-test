import React from "react";
import Link from "next/link"
import { bestselling as data } from "@/public/tempdata/bestSelling";
import ProductTile from "@/components/ProductTile"

const AllCategoryTypes = () => {
  return (
    <div className="bestselling-container">
      <div className="heading-container">
        <h2 className="heading">Best Selling Products</h2>
        <p className="para"> Best Products at greater discounts !</p>
      </div>
      <div className="listing-cards-container">
        {data?.length > 0 &&
          data?.map((item, i) => {
            return (
              <Link href={`/${item?.category}/${item?.id}`} key={i}>
                <ProductTile
                  id={item.id}
                  brand={item.brand}
                  color={item.color}
                  size={item.size}
                  image={item.image}
                  price={item.price}
                  deliveryType={item.deliveryType}
                  isWhishList={item.isWhishList}
                  item={item}
                  mrp={item.mrp}
                  rating={item.rating}
                  totalRating={item.totalRating}
                />
              </Link>
            );
          })}
      </div>
    </div>
  );
};

export default AllCategoryTypes;
