"use client";
import React, { useState, useEffect } from "react";
import { IoMdAdd, IoMdRemove } from "react-icons/io";
import axios from "axios"; // Import axios for API calls

const Filters = ({ loading, selectedFilters, setSelectedFilters ,getFilterProducts}) => {
  const [filterStates, setFilterStates] = useState({
    brand: false,
    price: false,
    rating: false,
  });

  const toggleFilter = (title) => {
    setFilterStates((prevState) => ({
      ...prevState,
      [title]: !prevState[title],
    }));
  };

  const filterData = [
    {
      title: "brand",
      values: ["kohel", "soch", "varanga", "arayana"],
    },
    {
      title: "price",
      values: [100, 500, 1000, 1500],
    },
    {
      title: "rating",
      values: [1, 2, 3, 4, 5],
    },
    
  ];

  const handleCheckboxChange = (filterType, value) => {
    setSelectedFilters((prevFilters) => {
      const updatedFilters = { ...prevFilters };
      if (updatedFilters[filterType]?.includes(value)) {
        updatedFilters[filterType] = updatedFilters[filterType]?.filter(
          (item) => item !== value
        );
      } else {
        updatedFilters[filterType] = [...updatedFilters[filterType], value];
      }
      return updatedFilters;
    });
  };

  // // Function to fetch data based on filters and update URL
  // const fetchData = async () => {
  //   const getFilterData = await getFilterProducts.bind(null, selectedFilters);

  //   try {
  //     const response = await getFilterData();
  //     console.log("@response", response);
  //     // const response = await axios.get(`/api/data?${queryString}`); // Replace `/api/data` with your API endpoint
  //     setLoading(false);
  //     setFilteredData(response); // Update filtered data state
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };

  // // Fetch data initially and on filter changes using useEffect
  // useEffect(() => {
  //   fetchData();
  // }, [selectedFilters]); // Re-run useEffect on changes to selectedFilters

  return (
    <div className="filters">
      {!loading &&
        filterData.map((filter, i) => (
          <div key={i} className="single-filter-container">
            <div
              key={i}
              className={`title-container ${
                filterData.length === i + 1 && "title-last"
              }`}
              onClick={() => toggleFilter(filter.title)}
            >
              <p>{filter.title}</p>
              {filterStates[filter.title] ? <IoMdRemove /> : <IoMdAdd />}
            </div>
            {filterStates[filter.title] && (
              <div className="values-container">
                {filter.values.map((value, index) => (
                  <div key={index}>
                    <label className="value">
                      <input
                        type="checkbox"
                        value={value}
                        checked={selectedFilters[filter.title]?.includes(value)}
                        onChange={() =>
                          handleCheckboxChange(filter?.title, value)
                        }
                      />
                      {value}
                    </label>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
    </div>
  );
};

export default Filters;
