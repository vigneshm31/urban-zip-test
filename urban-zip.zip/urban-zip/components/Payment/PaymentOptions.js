"use client";

import React, { useState, useEffect } from "react";
import { useFormState } from "react-dom";
import toast from "react-hot-toast";
const PaymentOptions = ({ handleOrder }) => {
  const [cartItems, setcartItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(null);
  const [selectTab, setselectTab] = useState(0);
  // const [state,handleAction]=useFormState(handleOrder,undefined)
  const paymentOptions = [
    {
      title: "Cash On Delivery",
      content: (
        <COD
          handleAction={handleOrder}
          cartItems={cartItems}
          totalPrice={totalPrice}
        />
      ),
    },
    {
      title: "Credit/Debit card",
      content: (
        <Card
          handleAction={handleOrder}
          cartItems={cartItems}
          totalPrice={totalPrice}
        />
      ),
    },
    {
      title: "Wallets",
      content: "cards",
    },
  ];

  const handleSelectTab = (i) => {
    setselectTab(i);
  };

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem("listCartItems")) || [];
    setcartItems(items);
    const prices = JSON.parse(localStorage.getItem("totalCartPriceList")) || {};
    setTotalPrice(prices?.sellingTotalPrice);
  }, []);
  return (
    <>
      <div className="heading-btn-container">
        <h2 className="heading">Choose Payment Methods</h2>
      </div>
      <div className="payments-container">
        <div className="payments-lists">
          <section className="left-container">
            <ul>
              {paymentOptions?.map((options, i) => {
                return (
                  <li
                    className={`list ${selectTab === i && "active"}`}
                    onClick={() => handleSelectTab(i)}
                    key={i}
                  >
                    {options.title}
                  </li>
                );
              })}
            </ul>
          </section>
          <section className="right-container">
            {paymentOptions[selectTab] && paymentOptions[selectTab].content}
          </section>
        </div>
      </div>
    </>
  );
};

export default PaymentOptions;

const COD = ({ handleAction, cartItems, totalPrice }) => {
  const handleSubmit = async (cart, totalPrice, paymentMethod) => {
    const newOrder = {
      orderId: Math.floor(1000 + Math.random() * 9000),
      items: [...cart],
      totalAmount: totalPrice,
      paymentMethod,
    };
    await handleAction(newOrder);
    localStorage.removeItem("listCartItems");
    toast.success("Order Placed Successfully");
  };
  return (
    <div className="cod-container">
      <div className="title">Cash on Delivery (Cash/UPI)</div>
      {totalPrice > 0 && (
        <button onClick={() => handleSubmit(cartItems, totalPrice, "COD")}>
          PLACE ORDER
        </button>
      )}
    </div>
  );
};
const Card = ({ handleAction, cartItems, totalPrice }) => {
  
  const handleSubmit = async (cart, totalPrice, paymentMethod) => {
    const newOrder = {
      orderId: Math.floor(1000 + Math.random() * 9000),
      items: [...cart],
      totalAmount: totalPrice,
      paymentMethod,
    };
    await handleAction(newOrder);
    localStorage.removeItem("listCartItems");
    toast.success("Order Placed Successfully");
  };
  return (
    <div className="cards-container">
      <p className="heading">Card Details</p>
      <div className="form">
        <input
          type="text"
          name="cardnumber"
          className="form__input"
          placeholder=" "
          id="cardnumber"
        />
        <label htmlFor="cardnumber" className="form__label">
          Card Number*
        </label>
      </div>
      <div className="form">
        <input
          type="text"
          name="cardname"
          className="form__input"
          placeholder=" "
          id="cardname"
        />
        <label htmlFor="cardname" className="form__label">
          Name on the Card*
        </label>
      </div>
      <div className="form">
        <input
          type="text"
          name="valid"
          className="form__input"
          autocomplete="off"
          placeholder=" "
          id="valid"
        />
        <label htmlFor="cardnumber" className="form__label">
          Valid Thru MM/YY*
        </label>
      </div>
      <div className="form">
        <input
          type="text"
          name="cvv"
          className="form__input"
          placeholder=" "
          id="cvv"
        />
        <label htmlFor="cvv" className="form__label">
          CVV*
        </label>
      </div>
      <button onClick={() => handleSubmit(cartItems, totalPrice, "Card")}>
        PAY NOW
      </button>
    </div>
  );
};
