"use client";
import React, { useEffect, useState } from "react";
import PriceList from "@/components/Cart/PriceList";
import Spinner from "@/components/Core/Spinner";
import PaymentOptions from "@/components/Payment/PaymentOptions";
const Payment = ({handleOrder}) => {
  const [prices, setPrices] = useState({});

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedPrices =
      JSON.parse(localStorage.getItem("totalCartPriceList")) || {};
    setPrices(storedPrices);
    setLoading(false);
  }, []);
  const { sellingTotalPrice, mrpTotalPrice, convenienceFees, discountAmount } =
    prices;
  return (
    <>
     <div className="flex-container">
      <div className="payment-list-container">
        <PaymentOptions handleOrder={handleOrder}/>
      </div>
      <div className="vertical-separator"></div>
      <div className="price-list-container">
        {loading ? (
          <Spinner />
        ) : (
          <PriceList
            sellingTotalPrice={sellingTotalPrice}
            mrpTotalPrice={mrpTotalPrice}
            convenienceFees={convenienceFees}
            discountAmount={discountAmount}
          />
        )}
      </div>
    </div>
    </>
  );
};

export default Payment;
