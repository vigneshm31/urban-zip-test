import React from "react";
import Link from "next/link"
import { makeup as data } from "@/public/tempdata/makeup";
import ProductTile from "./ProductTile";

const MakeUpKits = () => {
  return (
    <div className="bestselling-container">
      <div className="heading-container">
        <h2 className="heading">Best Selling MackUp</h2>
        <p className="para"> Best Products at greater discounts !</p>
      </div>
      <div className="listing-cards-container">
        {data?.length > 0 &&
          data?.map((item, i) => {
            return (
              <Link href={`/productDetails/${item.id}`} key={i}>
                <ProductTile
                  id={item.id}
                  brand={item.brand}
                  color={item.color}
                  size={item.size}
                  image={item.image}
                  price={item.price}
                  deliveryType={item.deliveryType}
                  isWhishList={item.isWhishList}
                  item={item}
                  mrp={item.mrp}
                  rating={item.rating}
                  totalRating={item.totalRating}
                />
              </Link>
            );
          })}
      </div>
    </div>
  );
};

export default MakeUpKits;
