import React from "react";
import { HeroBanner, BestSelling, TopBrands ,MakeUpKits} from "components";

const Home = () => {
  return (
    <>
      <div className="main-container">
        <HeroBanner />
        <BestSelling />
        <MakeUpKits/>
        <TopBrands />
      </div>
    </>
  );
};

export default Home;
