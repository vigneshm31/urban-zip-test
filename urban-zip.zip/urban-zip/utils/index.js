import { getSession } from "@/utils/server/auth-actions";
import { getUserByUserID } from "@/utils/server/actions";






// const CURRENCY_FORMATTER = new Intl.NumberFormat("en-IN", {
// 	style: 'currency',
// 	currency: 'IND',
//     currencyDisplay: 'code'
// });
const CURRENCY_FORMATTER = new Intl.NumberFormat("en-IN",);

export const formatCurrency = (number)=>{
    return CURRENCY_FORMATTER.format(number)
}

export const getUserData=async()=>{
    const session= await getSession()
    const userData=await getUserByUserID(session?.userId)
    return userData
 

}

export const formatDate=(date)=>{
    const originalDate = new Date(date);
    const formattedDate = originalDate.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
    }).replace(/\//g, '-');
    return formattedDate
}