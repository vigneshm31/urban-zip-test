import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    userId: {
      type: Number,
      required: true,
    },
    userName: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    confirmPassword: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      max: 40,
    },
    userReview: {
      type: String,
    },
    wishlist: {
      type: [String], // Array of product IDs
    },
    img: {
      type: String,
    },
    isAdmin: {
      type: Boolean,
      default: false,
    },
    addresses: [
      {
        customername:String,
        mobilenumber:String,
        pincode: String,
        street: String,
        locality:String,
        city: String,
        state: String,
      },
    ],
    cart: {
      items: [
        {
          productId: String,
          quantity: Number,
        },
      ],
    },
    orders: [
      {
        orderId: {
          type: String,
        },
        items: [
          {
            productId: String,
            selectedSize:String,
            quantity: Number,
            productName:String,
            productImage:String
          },
        ],
        totalAmount: {
          type: Number,
          required: true,
        },
        paymentMethod: {
          type: String,
          required: true,
        },
        orderStatus: {
          type: String,
          enum: ["pending", "processing", "delivered", "cancelled"],
          default: "pending",
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
        updatedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  { timestamps: true }
);

const productSchema = new mongoose.Schema(
  {
    imageUrl: {
      type: String,
      required: true,
    },
    imageUrlFull: {
      type: String,
      required: true,
    },
    productName: {
      type: String,
      required: true,
    },
    productId: {
      type: String,
      required: true,
    },
    brand: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    fashionType: {
      type: String,
      required: true,
    },
    price: {
      type: String,
      required: true,
    },
    mrp: {
      type: String,
      required: true,
    },
    size: {
      type: Array,
      required: true,
    },
    returnOptions: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    stock: {
      type: String,
      required: true,
    },
    delivery: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

const reviewSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    reviewPlaceId: {
      type: Number,
      required: true,
    },
    reviewPlaceId: {
      type: Number,
      required: true,
    },
    reviewPlaceId: {
      type: Number,
      required: true,
    },
    rating: {
      type: Number,
      required: true,
    },
    month: {
      type: String,
      required: true,
    },
    peoples: {
      type: String,
      required: true,
    },
    reviewDesc: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

//if already existing user/post in db use that or create one new
export const Users = mongoose.models?.Users || mongoose.model("Users", userSchema);
export const Products =
  mongoose.models?.Products || mongoose.model("Products", productSchema);
export const Reviews =
  mongoose.models?.Reviews || mongoose.model("Reviews", reviewSchema);

//with this models we can ready to create new user, add ,update, delete
