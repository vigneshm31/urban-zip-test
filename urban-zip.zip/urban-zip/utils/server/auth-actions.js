"use server";
import { connectToDb } from "@/utils/server/connectToDb";
import { Users } from "@/utils/server/models";
import { unstable_noStore as noStore, revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { defaultSession, sessionOptions } from "./auth-sessionOptions";
import { getIronSession } from "iron-session";
import { cookies } from "next/headers";

export const register = async (prevState, postUserData) => {
  const { userName, mobileNumber, email, password, confirmPassword } =
    Object.fromEntries(postUserData);
  try {
    connectToDb();
    if (!userName || !mobileNumber || !email || !password || !confirmPassword) {
      return {
        error: "Please fill in all required fields",
      };
    }
    const user = await Users.findOne({ userName });
    if (user) {
      return {
        error: "Name already exits",
      };
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = new Users({
      userId: Math.floor(1000 + Math.random() * 9000),
      userName,
      mobileNumber,
      email,
      password,
      confirmPassword,
      isAdmin: false,
    });
    await newUser.save();
    console.log("@new user saved to db");
    revalidatePath(`/user-auth`);
    return { success: "Register Success" };
  } catch (error) {
    console.log("Error in sending new user ", error);
    throw new Error("Error in sending new user", error);
  }
  // redirect(`/`);
};

export const getSession = async () => {
  const session = await getIronSession(cookies(), sessionOptions); //need to pass user cookies , options o get user cokies, dcrypt using sessionoption password
  if (!session.isLoggedIn) {
    session.isLoggedIn = defaultSession.isLoggedIn;
  }

  return session;
};
export const userLogin = async (prevState, formData) => {
  const session = await getSession();
  const { userName, password } = Object.fromEntries(formData);
  try {
    connectToDb();
    const user = await Users.findOne({ userName });
    if (userName !== user?.userName) {
      return {
        error: "wrong username",
      };
    }
    if (password !== user?.password) {
      return {
        error: "wrong password",
      };
    }
    session.userName = userName;
    session.userId = user.userId;
    session.isLoggedIn = true;
    session.isAdmin = user?.isAdmin;
    await session.save();
    return { success: "Login Success" };
  } catch (error) {
    console.log("Error in sending new user ", error);
    throw new Error("Error in sending new user", error);
  }
};

export const userLogout = async () => {
  const session = await getSession();
  session.destroy();
  redirect("/");
};
