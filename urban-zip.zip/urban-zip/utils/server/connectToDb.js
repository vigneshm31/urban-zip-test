const { default: mongoose } = require("mongoose")

//check for connection, if already there, then use that existing connection
const connections={}

export const connectToDb=async()=>{
    try {
        if(connections.isConnected){
            console.log("using existing connection")
            return;
        }
        const db= await mongoose.connect(process.env.MONGO)

        console.log("connected to db")
        connections.isConnected=db.connections[0].readyState;
       
    } catch (error) {
        console.log("Error in ConnectTodb",error) 
        throw new Error("Error in ConnectTodb ",error)
    }
}