export const sessionOptions ={
    password:process.env.SECRET_KEY,
    cookieName:"user-data",
    cookieOptions:{
        httpOnly:true,//it prevent client side js from access the our cookie , only in server site
        secure:process.env.NODE_ENV==="production" ?? false
    }, 


}
export const defaultSession={
    isLoggedIn:false
}