"use server";
import { connectToDb } from "@/utils/server/connectToDb";
import { Reviews, Products, User, OneTest, Users } from "@/utils/server/models";
import { unstable_noStore as noStore, revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getSession } from "./auth-actions";

export const addProductToDb = async (postFormData) => {
  const {
    imageUrl,
    imageUrlFull,
    productName,
    productId,
    brand,
    category,
    fashionType,
    price,
    mrp,
    size,
    returnOptions,
    description,
    stock,
    delivery,
  } = Object.fromEntries(postFormData);
  try {
    connectToDb();

    const newProduct = new Products({
      imageUrl,
      imageUrlFull,
      productName,
      productId,
      brand,
      category,
      fashionType,
      price,
      mrp,
      size,
      returnOptions,
      description,
      stock,
      delivery,
    });
    await newProduct.save();
    console.log("@saved to db");
    revalidatePath("/my-account/products");
  } catch (error) {
    console.log("Error in sending products", error);
    throw new Error("Error in sending products", error);
  }
  redirect(`/my-account/products`);
};
export const getProductFromDB = async () => {
  noStore();
  try {
    connectToDb();
    const products = await Products.find();
    return products;
  } catch (error) {
    console.log("Error in fetch products", error);
    throw new Error("Error in fetch products", error);
  }
};
export const getProductByCategoryFromDB = async (urlCategory) => {
  noStore();
  try {
    connectToDb();
    const query = { fashionType: `${urlCategory}` };
    const products = await Products.find(query);
    return products;
  } catch (error) {
    console.log("Error in fetch category products", error);
    throw new Error("Error in fetch category products", error);
  }
};
export const getProductByPdpIdFromDB = async (pdpId) => {
  noStore();
  try {
    connectToDb();
    const query = { productId: `${pdpId}` };
    const products = await Products.find(query);
    return products;
  } catch (error) {
    console.log("Error in fetch  products for PDP", error);
    throw new Error("Error in fetch  products for PDP", error);
  }
};
export const getProductByProductIdsForCartFromDB = async (productIds) => {
  noStore();
  try {
    connectToDb();
    const query = { productId: { $in: productIds } }; // Using $in operator to match any of the productIds in the array
    const products = await Products.find(query);
    return products;
  } catch (error) {
    console.log("Error in fetch  products for cart", error);
    throw new Error("Error in fetch  products for cart", error);
  }
};
export const editProductFromDB = async (_id, postFormData) => {
  const {
    imageUrl,
    imageUrlFull,
    productName,
    productId,
    brand,
    category,
    fashionType,
    price,
    mrp,
    size,
    returnOptions,
    description,
    stock,
    delivery,
  } = Object.fromEntries(postFormData);

  try {
    connectToDb();

    await Products.findByIdAndUpdate(
      _id,
      {
        imageUrl,
        imageUrlFull,
        productName,
        productId,
        brand,
        category,
        fashionType,
        price,
        mrp,
        size,
        returnOptions,
        description,
        stock,
        delivery,
      },
      {
        new: true,
      }
    );
    revalidatePath(`/my-account/products`);
  } catch (error) {
    console.log("Error in editied products", error);
    throw new Error("Error in editied products", error);
  }
  redirect(`/my-account/products`);
};
export const getSingleProductFromDB = async (productId) => {
  noStore();
  try {
    connectToDb();
    const product = await Products.findOne({ productId });
    return product;
  } catch (error) {
    console.log("Error in get single product", error);
    throw new Error("Error in get single product", error);
  }
};
export const deleteProductFromDB = async (deletePostId) => {
  try {
    connectToDb();
    await Products.findByIdAndDelete(deletePostId);
    revalidatePath(`/my-account/products`);
  } catch (error) {
    console.log("Error in deleting product", error);
    throw new Error("Error in deleting product", error);
  }
  redirect(`/my-account/products`);
};
export const deleteAllProductsFromDB = async () => {
  try {
    connectToDb();
    await Products.deleteMany({}); // Delete all products
    revalidatePath(`/my-account/products`);
  } catch (error) {
    console.log("Error in deleting all products", error);
    throw new Error("Error in deleting all products", error);
  }
  redirect(`/my-account/products`);
};

const buildQueryObject = (filters, urlCategory) => {
  const queryObject = {
    fashionType: `${urlCategory}`,
  };

  if (filters) {
    if (filters.brand && filters.brand.length > 0) {
      queryObject.brand = { $in: filters.brand };
    }
    if (filters.price && filters.price.length > 0) {
      const sortedPrices = [...filters.price].sort((a, b) => a - b);
      if (sortedPrices.length === 1) {
        queryObject.price = sortedPrices[0];
      } else {
        queryObject.price = {
          $gte: sortedPrices[0],
          $lte: sortedPrices[sortedPrices.length - 1],
        };
      }
    }
    if (filters.rating && filters.rating.length > 0) {
      queryObject.rating = { $in: filters.rating };
    }
  }

  return queryObject;
};
export const getFilterProducts = async (filters, urlCategory, skip, limit) => {
  noStore();
  try {
    connectToDb();

    const query = buildQueryObject(filters, urlCategory); // Construct the query object

    const products = await Products.find(query); // Fetch trips based on the query object
    // const trips = await Trips.find(query).skip(skip).limit(limit); // Fetch trips based on the query object
    return products;
  } catch (error) {
    console.log("Error in fetch filter products", error);
    throw new Error("Error in fetch filter products", error);
  }
};

export const getUserByUserID = async (userId) => {
  noStore();
  try {
    connectToDb();
    // const user = await Users.findOne({ userId });
    // const user = await Users.findOne({ userId }).select('-password');
    const user = await Users.findOne({ userId }).select(
      "-password -confirmPassword"
    );

    return user;
  } catch (error) {
    console.log("Error in get single user data", error);
    throw new Error("Error in get single user data", error);
  }
};

export const addWishListToDb = async (userId, productId) => {
  try {
    connectToDb();

    const user = await Users.findOne({ userId });
    if (!user) {
      throw new Error("User not found");
    }
    user.wishlist.push(productId);
    await user.save();
    revalidatePath(`/products/${slug}`);
    return { message: "Wishlist updated successfully" };
  } catch (error) {
    return { message: "Failed to update wishlist", error: error.message };
  }
};
export const removeWishListFromDb = async (userId, productId) => {
  try {
    connectToDb();

    const user = await Users.findOne({ userId });
    if (!user) {
      throw new Error("User not found");
    }
    user.wishlist = user.wishlist.filter((item) => item !== productId);
    await user.save();
    revalidatePath(`/products/${slug}`);
    return { message: "Product removed from wishlist successfully" };
  } catch (error) {
    return {
      message: "Failed to remove product from wishlist",
      error: error.message,
    };
  }
};
export const addAddressToDb = async (prev, postFormData) => {
  const { userId } = await getSession();
  const {
    customername,
    mobilenumber,
    pincode,
    street,
    locality,
    city,
    state,
    defaultaddress,
  } = Object.fromEntries(postFormData);
  try {
    connectToDb();

    const user = await Users.findOne({ userId });
    if (!user) {
      throw new Error("User not found");
    }
    const newAddress = {
      customername,
      mobilenumber,
      pincode,
      street,
      locality,
      city,
      state,
      defaultaddress,
    };
    user.addresses.push(newAddress);
    await user.save();
    revalidatePath(`/checkout`);
    return { success: "address updated successfully" };
  } catch (error) {
    return { error: "Failed to update address", error: error.message };
  }
  // redirect(`/checkout`);
};

export const handleOrder = async (newOrder) => {
  const { userId } = await getSession();
  try {
    connectToDb();

    const user = await Users.findOne({ userId });
    if (!user) {
      throw new Error("User not found");
    }
    user.orders.push(newOrder);
    await user.save();
    revalidatePath(`/payment`);
  } catch (error) {
    return { message: "Failed to order", error: error.message };
  }
  redirect("/order-success");
};
export const getOrdersFromDB = async () => {
  noStore();
  const { userId } = await getSession();

  try {
    connectToDb();
    const user = await Users.findOne({ userId });
    if (user.isAdmin) {
      const orders = await Users.find({}, "orders");
      return orders;
    } else {
      return { error: "Forbidden" };
    }
  } catch (error) {
    console.log("Error in fetching orders", error);
    throw new Error("Error in fetching orders", error);
  }
};

export const fetchSearchProducts = async (q,page,ITEM_PER_PAGE) => {
  const regex = new RegExp(q, "i"); // Include the "i" flag for case-insensitive matching
  noStore();
  try {
    connectToDb();
    const totalCount=await Products.find({ productName: { $regex: regex } }).count();
    const products = await Products.find({ productName: { $regex: regex } }).limit(ITEM_PER_PAGE).skip(ITEM_PER_PAGE * (page-1)); //skip. 0 on first page ,skip first two on second page
    return {totalCount,products};
  } catch (error) {
    console.log("Error in fetch products", error);
    throw new Error("Error in fetch products", error);
  }
};
export const fetchOrdersForAdmin = async (q, page, ITEM_PER_PAGE) => {
  const regex = new RegExp(q, "i"); // Include the "i" flag for case-insensitive matching

  noStore();
  const { userId } = await getSession();

  try {
    connectToDb();
    const user = await Users.findOne({ userId });
    if (user?.isAdmin) {
      const totalCount = await Users.countDocuments({
        "orders.orderId": { $regex: regex },
      });
      const orders = await Users.find(
        { "orders.orderId": { $regex: regex } },
      )
      .limit(ITEM_PER_PAGE).skip(ITEM_PER_PAGE * (page-1)); //skip. 0 on first page ,skip first two on second page
      return { totalCount, orders };
    } else {
      return { error: "Forbidden" };
    }
  } catch (error) {
    console.log("Error in fetching orders", error);
    throw new Error("Error in fetching orders", error);
  }
};


