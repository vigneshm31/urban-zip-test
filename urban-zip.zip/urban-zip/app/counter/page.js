"use client";
import React from "react";
import { increment,decrement,reset } from "@/redux/features/counterSlice";
import { useAppDispatch, useAppSelector } from "@/redux/hooks";

const Counter = () => {
    const count=useAppSelector((state)=>state.counter.value)
 
    const dispatch = useAppDispatch();
  return (
    <>
    <div style={{ display:"flex",gap:"20px",flexDirection:"column",justifyContent:"center",alignItems:"center",margin:"30px 0px"}}>
    <div >{count}</div>
      <div >
        Counter
        
      </div>
      <div style={{display:"flex",gap:"20px"}}>
      <button onClick={()=>dispatch(increment())}>Add</button>
      <button onClick={()=>dispatch(decrement())}>Sub</button>
      <button onClick={()=>dispatch(reset())}>reset</button>
      </div>
      </div>
    </>
  );
};

export default Counter;
