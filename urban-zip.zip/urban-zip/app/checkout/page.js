import React from "react";
import CheckoutComponent from "@/components/Checkout/Checkout";
import { addAddressToDb } from "@/utils/server/actions";
import { getUserData } from "@/utils";


export const metadata = {
  title: "Address | Urban Threads",
  description: "Products Page desc",
};

const Checkout = async() => {
  const userData= await getUserData();
  let addresses=[]
  if (userData && userData.addresses) {
    addresses=userData.addresses
  }
  return (
    <div className="checkout-container">
      <CheckoutComponent addAddressToDb={addAddressToDb} addresses={JSON.stringify(addresses)}/>
    </div>
  );
};

export default Checkout;
