import React from 'react'

export const metadata = {
    title: "address | checkout", 
    description: "address and checkout page",
  };
const Layout = ({children}) => {
  return (

    <div>{children}</div>
  )
}

export default Layout