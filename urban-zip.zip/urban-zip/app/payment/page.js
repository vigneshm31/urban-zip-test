import React from "react";
import PaymentComponent from "@/components/Payment/Payment";
import { getUserData } from "@/utils";
import { handleOrder } from "@/utils/server/actions";


export const metadata = {
  title: "Payment | Urban Threads",
  description: "Payment Page",
};

const Payment = async() => {
  const userData= await getUserData();
  
  return (
    <div className="payment-container">
      <PaymentComponent handleOrder={handleOrder}/>
    </div>
  );
};

export default Payment;
