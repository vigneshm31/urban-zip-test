import React from "react";
import Sidebar from "@/components/MyAccount/Sidebar"


const MyAccount = ({ children }) => {
  return (
    <>
      <div className="my-account">
        <div className="main-container">
          <div className="side-menu-container">
            <aside>
              <Sidebar/>
            </aside>
          </div>

          <main className="main-content-container">
            {children}
          </main>
        </div>
      </div>
    </>
  );
};

export default MyAccount;
