import React from 'react'
import { editProductFromDB,getSingleProductFromDB } from "@/utils/server/actions";
import EditProduct from '@/components/MyAccount/Products/EditProduct'

export const metadata = {
  title: "Edit Products",
  description: "Products Page desc",
};

const EditProducts = async({params,searchParams}) => {
  const editProductId=searchParams?.productId

  const productToEditData= await getSingleProductFromDB(editProductId)
  return (
    <>
    <EditProduct productToEditData={JSON.stringify(productToEditData)} editProductFromDB={editProductFromDB}/>
    </>
  )
}

export default EditProducts