import AddProduct from '@/components/MyAccount/Products/AddProduct'
import React from 'react'
import { addProductToDb } from "@/utils/server/actions";

export const metadata = {
  title: "Add New Products",
  description: "Products Page desc",
};

const AddProducts = () => {
  return (
    <>
    <AddProduct addProductToDb={addProductToDb} />
    </>
  )
}

export default AddProducts