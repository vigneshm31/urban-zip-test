import React from "react";
import ProductView from "@/components/MyAccount/Products/Product.View";
import {
  getProductFromDB,
  deleteProductFromDB,
  deleteAllProductsFromDB,
  fetchSearchProducts,
} from "@/utils/server/actions";

export const metadata = {
  title: "Products",
  description: "Products Page desc",
};

const Products = async ({ searchParams }) => {
  const q = searchParams?.q || "";
  const page = searchParams?.page || 1;
  const ITEM_PER_PAGE=searchParams?.rowsPerPage || 5;
  const {totalCount,products} = await fetchSearchProducts(q, page,ITEM_PER_PAGE);
  return (
    <>
      <ProductView
        productsDataFromDb={JSON.stringify(products)}
        deleteProductFromDB={deleteProductFromDB}
        deleteAllProductsFromDB={deleteAllProductsFromDB}
        totalCount={totalCount}
      />
    </>
  );
};

export default Products;
