import React from "react";
import { getOrdersFromDB, fetchOrdersForAdmin } from "@/utils/server/actions";
import Orders from "@/components/MyAccount/Orders/Orders";

export const metadata = {
  title: "Orders | Urban Threads",
  description: "Orders Page",
};

const OrdersPage = async ({ searchParams }) => {
  const q = searchParams?.q || "";
  const page = searchParams?.page || 1;
  const ITEM_PER_PAGE = searchParams?.rowsPerPage || 5;

  // const { totalCount, orders } = await fetchOrdersForAdmin(
  //   q,
  //   page,
  //   ITEM_PER_PAGE
  // );
  const  orders  = await getOrdersFromDB()
  return (
    <>
      {orders?.length > 0 ? (
        <>
          <Orders orders={JSON?.stringify(orders)} 
          // totalCount={totalCount} 
          />
        </>
      ) : (
        <p>No order Found</p>
      )}
    </>
  );
};

export default OrdersPage;
