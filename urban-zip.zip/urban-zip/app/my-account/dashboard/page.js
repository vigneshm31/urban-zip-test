import React from "react";
import Link from "next/link";
import { FaArrowRightToBracket } from "react-icons/fa6";
import StickyFilter from "@/components/MyAccount/Products/StickyFilter/StickyFilter";
import SalesReport from "@/components/MyAccount/Dashboard/SalesReport";
import Earning from "@/components/MyAccount/Dashboard/Earning";
import OverviewCards from "@/components/MyAccount/Dashboard/OverviewCards";
import Table from "@/components/MyAccount/Dashboard/Table";
export const metadata = {
  title: "DashBoard",
  description: "DashBoard Page desc",
};

const Dashboard = () => {
  return (
    <>
      <div className="page-header-container">
        <div className="heading">
          <h3>Dashboard</h3>
        </div>

        <div className="view-store-link">
          <Link href={"/"}>
            View Your Store <FaArrowRightToBracket />
          </Link>
        </div>
      </div>
      <div className="page-main-container">
        <div className="dashboard-main-content">
          <div className="dashboard-chart-order">
          <div className="dashboard-charts-section">
            <div className="sections">
              <div className="sales">
                <SalesReport />
              </div>
              {/* <div className="earning">
              <Earning/>
          </div> */}
            </div>
          </div>
          <div className="vertical-separator"></div>

          <div className="dashboard-overview-cards-section">
            <OverviewCards />
          </div>
          </div>
          <div className="dashboard-table">
            <Table/>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
