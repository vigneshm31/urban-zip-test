import HeroBanner from "@/components/HeroBanner";
import BestSelling from "@/components/BestSelling";
import MakeUpKits from "@/components/MakeUpKits";
import TopBrands from "@/components/TopBrands";
import NewProducts from "@/components/NewProducts";
import Image from "next/image";
import styles from "./page.module.css";

export const metadata = {
  title: "Home | Urban threads", 
  description: "urban Threads Home Page",

};
export default function Home() {
  return (
    <>
      <div className="main-container">  
        <HeroBanner />
        <div
        className="home-container"
        style={{
          height: "500px",
          backgroundImage:"url('/images/home2.png')",
            
          backgroundPosition: "center",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
        }}
      >
        </div>
        {/* <NewProducts/> */}
        <BestSelling />
        <MakeUpKits />
        <TopBrands />
      </div>
    </>
  );
}
