import React from "react";
import ProductImage from "@/components/ProductDetails/ProductImage";
import ProductDescription from "@/components/ProductDetails/ProductDescription";
import { getProductByPdpIdFromDB ,addWishListToDb,removeWishListFromDb} from "@/utils/server/actions";
import { getUserData } from "@/utils";

export const metadata = {
  title: "PDP | Urban threads", 
  description: "urban Threads PDP Page",

};
const ProductDetails = async ({ params }) => {
  const { pdpId } = params;
  const pdpProductId = pdpId;
  const singleProduct = await getProductByPdpIdFromDB(pdpProductId);

const userData=await getUserData()
const { cart = [], wishlist = [], userId = '' } = userData || {};

  const imageFullUrl =
    "https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24014310/2023/7/14/e0d643e5-05bc-4249-833b-0ddf80440f851689274793057BULLMERMenBeigePrintedV-NeckPocketsT-shirt1.jpg";
  return (
    <div className="product-details-main-container">
      <div className="flex-container">
        {singleProduct?.map((item,i) => {
          return (
            <>
              <div className="img-container" key={i}>
                <ProductImage imgUrl={item.imageUrlFull ?? imageFullUrl} />
              </div>
              <div className="describe-container">
                <ProductDescription
                  id={item.id}
                  brand={item.brand}
                  description={item.description}
                  color={item.color}
                  delivery={item.deliveryType}
                  price={item.price}
                  size={item.size}
                  rating={item.rating}
                  totalRating={item.totalRating}
                  mrp={item.mrp}
                  isWhishList={item.isWhishList}
                  material={item.material ?? ["cotton"]}
                  productName={item.productName}
                  productImage={item.imageUrl}
                  productId={item.productId}
                  category={item.category}
                  userCart={cart}
                  userWishList={wishlist}
                  userId={userId}
                  addWishListToDb={addWishListToDb}
                  removeWishListFromDb={removeWishListFromDb}
                />
              </div>
            </>
          );
        })}
        
      </div>
    </div>
  );
};

export default ProductDetails;
