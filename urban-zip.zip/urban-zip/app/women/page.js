import HeroBanner from "@/components/HeroBanner";
import BestSelling from "@/components/BestSelling";
import MakeUpKits from "@/components/MakeUpKits";
import TopBrands from "@/components/TopBrands";
import Image from "next/image";
import CategoryCards from "@/components/Core/CategoryCards";
import kurta from "@/public/images/women/kurta.png";
import saree from "@/public/images/women/saree.png";
import tops from "@/public/images/women/tops.png";
import tshirt from "@/public/images/women/tshirts.png";

export const metadata = {
  title: "Category | Urban threads", 
  description: "urban Threads Category Page",

};

export default function Women() {
  const categoryData = [
    {
      img: kurta,
      value: "Kurtas",
      url:"women/kurta"
    },
    {
      img: saree,
      value: "Sarees",
      url:"women/saree"
    },
    {
      img: tops,
      value: "Tops",
      url:"women/tops"
    },
    {
        img: tshirt,
        value: "T-shirts",
        url:"women/t-shirts"
      },
  ];
  return (
    <>
      <div className="main-container">
        <div
          className="home-container"
          style={{
            height: "400px",
            backgroundImage: "url('/images/women-banner1.png')",

            backgroundPosition: "center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            objectFit: "cover",
          }}
        ></div>
        <CategoryCards categoryData={categoryData} />
        {/* <BestSelling />
        <MakeUpKits /> */}
        <TopBrands />
      </div>
    </>
  );
}
