import AuthIndex from '@/components/Auth/AuthIndex'
import { register, userLogin} from '@/utils/server/auth-actions';
import React from 'react'

export const metadata = {
  title: "Auth | Urban Threads",
  description: "Auth Page",
};

const Auth = () => {
  return (
    <div className='auth-page-container'>
        <AuthIndex register={register} userLogin={userLogin} 
        />
    </div>
  )
}

export default Auth