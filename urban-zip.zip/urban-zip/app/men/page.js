import HeroBanner from "@/components/HeroBanner";
import BestSelling from "@/components/BestSelling";
import MakeUpKits from "@/components/MakeUpKits";
import TopBrands from "@/components/TopBrands";
import Image from "next/image";
import CategoryCards from "@/components/Core/CategoryCards";
import shirt from "@/public/images/men/shirt.png";
import shoes from "@/public/images/men/shoes.png";
import tshirt from "@/public/images/men/tshirt.png";
import jean from "@/public/images/men/jean.png";
export default function Men() {
  const categoryData = [
    {
      img: shirt,
      value: "Shirt",
      url:"men/shirt"
    },
    {
      img: jean,
      value: "Jean",
      url:"men/jean"
    },
    {
      img: tshirt,
      value: "T-shirt",
      url:"men/t-shirts"
    },
    {
        img: shoes,
        value: "Shoes",
        url:"men/shoes"
      },
  ];
  return (
    <>
      <div className="main-container">
        <div
          className="home-container"
          style={{
            height: "400px",
            backgroundImage: "url('/images/men1.png')",

            backgroundPosition: "center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            objectFit: "cover",
          }}
        ></div>
        <CategoryCards categoryData={categoryData}/>
        <BestSelling />
        <MakeUpKits />
        <TopBrands />
      </div>
    </>
  );
}
