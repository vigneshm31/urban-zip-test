import React from 'react'

export const metadata = {
  title: "Product details page",
  description: "product details page",
};
const Layout = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default Layout