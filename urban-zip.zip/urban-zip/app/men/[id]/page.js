import PLP from "@/components/PLP/PLP";
import { getProductFromDB,getProductByCategoryFromDB,getFilterProducts } from "@/utils/server/actions";
import React from "react";


export const metadata = {
  title: "PLP | Urban threads", 
  description: "urban Threads Category Page",

};
const ProductDetails = async({params}) => {
  const {id} = params
  const urlCategory = id?.toLowerCase();
  const products=await getProductByCategoryFromDB(urlCategory)
  return (
    <>
    <PLP products={JSON.stringify(products)} urlCategory={urlCategory}getFilterProducts={getFilterProducts}/>
    </>
   
  );
};

export default ProductDetails;
