import Success from "@/components/Success/Success";
import React from "react";

export const metadata = {
  title: "Order Success | Urban Threads",
  description: "Order Success Page",
};

const OrderSuccess = async() => {
  
  return (
    <div className="success-container">
      <Success/>
    </div>
  );
};

export default OrderSuccess;
