import React from "react";
import Orders from "@/components/Orders/Orders";
import { getUserData } from "@/utils";
import { getProductByProductIdsForCartFromDB } from "@/utils/server/actions";

export const metadata = {
  title: "Order Success | Urban Threads",
  description: "Order Success Page",
};

const OrdersPage = async () => {
  const userData = await getUserData();
  const { orders = [] } = userData || {};
  return (
    <div className="order-container">
      {orders.length > 0 ? (
        <>
          <p>Order Details</p>
          <Orders
            getProductByProductIdsForCartFromDB={
              getProductByProductIdsForCartFromDB
            }
            orders={JSON.stringify(orders)}
          />
        </>
      ) : (
        <p>No order Found</p>
      )}
    </div>
  );
};

export default OrdersPage;
