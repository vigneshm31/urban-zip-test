import WishlistView from "@/components/Wishlist/Wishlist.View";
import { getUserData } from "@/utils";
import { getProductByProductIdsForCartFromDB } from "@/utils/server/actions";

import React from "react";

export const metadata = {
  title: "Wishlist | Urban threads",
  description: "urban Threads wishlist Page",
};
const WishlistPage = async () => {
  const userData =await getUserData();
 const { wishlist: wishListProductIDs=[] }=userData || {}
 
  return (
    <>
      <WishlistView getProductByProductIdsForCartFromDB={getProductByProductIdsForCartFromDB} wishListProductIDs={wishListProductIDs}/>
    </>
  );
};

export default WishlistPage;
