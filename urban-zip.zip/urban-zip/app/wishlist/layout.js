import React from 'react'

export const metadata = {
  title: "wishlist | urban threads",
  description: "wishlist page",
};
const Layout = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default Layout