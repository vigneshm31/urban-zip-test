import React from "react";
import CartComponent from "@/components/Cart/Cart";
import { getProductByProductIdsForCartFromDB } from "@/utils/server/actions";
export const metadata = {
  title: "Cart | Urban threads", 
  description: "urban Threads cart Page",

};
const Cart = async () => {
  return <div className="cart-container">
    <CartComponent getProductByProductIdsForCartFromDB={getProductByProductIdsForCartFromDB}/>
  </div>;
};

export default Cart;
