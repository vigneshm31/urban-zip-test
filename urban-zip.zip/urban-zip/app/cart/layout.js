import React from 'react'

export const metadata = {
    title: "Cart", 
    description: "cart page",
  };
const Layout = ({children}) => {
  return (

    <div>{children}</div>
  )
}

export default Layout