import img1 from "@/public/images/makeup/1.webp";
import img2 from "@/public/images/makeup/2.webp";
import img3 from "@/public/images/makeup/3.webp";
import img4 from "@/public/images/makeup/4.webp";
import img1D from "@/public/images/makeup/5detail.jpg";
import img2D from "@/public/images/makeup/6detail.jpg";
import img3D from "@/public/images/makeup/7detail.jpg";
import img4D from "@/public/images/makeup/8detail.webp";
export const kids = [
  {
    id: 17,
    name: "H & M Boys White T-shirt",
    brand: "h&m",
    description: "H&M Boys White Pure Cotton Slim Fit T-shirt",
    color: "white",
    price: 449,
    category: "kids",
    mrp: 1299,
    stock: 4500,
    sold: 214,
    rating: "4.2",
    totalRating: "1286",
    deliveryType: "Free Delivery",
    image: img1,
    isWhishList: false,
    imageFull: img1D,
    imageUrl:
      "https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/19283072/2022/7/28/f1c134f7-4f4b-42ad-8d49-f03042ed8bf21659002013493CottonT-shirt1.jpg",
    material: ["100% cotton", "Machine-wash", "Regular Fit"],
    isActionOpen:false,
  },
  {
    id: 18,
    name:'New York Disney',
    brand: "Yn Display",
    description:
      "H&M Infant Boys Pure Cotton Long-Sleeved T-shirt",
    color: "kids",
    price: 520,
    category: "kids",
    mrp: 1299,
    stock: 200,
    sold: 20,
    rating: "3.4",
    totalRating: "28",
    deliveryType: "Free Delivery",
    image: img2,
    isWhishList: false,
    imageFull: img2D,
    imageUrl:
      "https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/25154690/2023/9/25/d5080e34-685b-4158-99b2-c89bc094ffc21695647567905HMBoysPrintedPureCottonT-Shirt1.jpg",
    material: ["100% cotton", "Machine-wash", "Regular Fit"],
    isActionOpen:false,
  },
  {
    id: 19,
    name:"Men Blue White",
    brand: "Ponds",
    description: "Men Teal Blue White Printed Round Neck Pure Cotton T-shirt",
    color: "yellow",
    rating: "4.9",
    totalRating: "2845",
    deliveryType: "Delivery @ Rs 39",
    price: 170,
    category: "kids",
    mrp: 799,
    stock: 200,
    sold: 20,
    image: img3,
    isWhishList: false,
    imageFull: img3D,
    imageUrl:
      "https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/23611434/2023/6/13/350a8051-bcd2-4b71-a597-2f7dd0c5af9e1686601369414CottonHenleytop1.jpg",
    material: ["100% cotton", "Machine-wash", "Regular Fit"],
    isActionOpen:false,
  },
  {
    id: 20,
    name:"Men White Black Printed",
    brand: "BEEtee",
    description: "Men White Black Printed Pure Cotton T-shirt",
    color: "green",
    mrp: 799,
    category: "kids",
    stock: 200,
    sold: 20,
    rating: "4.0",
    totalRating: "2468",
    deliveryType: "Free Delivery",
    price: 120,
    image: img4,
    isWhishList: true,
    imageFull: img4D,
    imageUrl:
      "https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/23539684/2023/6/6/ad3fd70b-f8c3-4e3a-b845-662bb9929d271686038350995CottonHenleytop1.jpg",
    material: ["100% cotton", "Machine-wash", "Regular Fit"],
    isActionOpen:false,
  },
];
