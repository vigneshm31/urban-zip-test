export const  navBarMenu=[
    {
        id:1,
        name:"Men",
        href:"/men"
    },
    {
        id:2,
        name:"Women",
        href:"/women"
    },
    {
        id:3,
        name:"Kids",
        href:"/kids"
    },
    {
        id:4,
        name:"Beauty",
        href:"/beauty"
    }
]

export const navBarCheckout=[
    {
        id:1,
        name:"Bag",
        href:"/cart"
    },
    {
        id:1,
        name:"Address",
        href:"/checkout"
    },
    {
        id:1,
        name:"Payment",
        href:"/payment"
    },
]


