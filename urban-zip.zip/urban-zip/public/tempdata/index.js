import { bestselling } from "@/public/tempdata/bestSelling";
import { makeup } from "@/public/tempdata/makeup";
import { kids } from "@/public/tempdata/kids";


export const allData=[...bestselling,...makeup,...kids];

