const { createSlice } = require("@reduxjs/toolkit");

const initialState = {
  wishListItems: [],
};

const wishListSlice = createSlice({
  name: "wishListItems",
  initialState,
  reducers: {
    addToWishList: (state, action) => {
      const { productId } = action.payload;
      const newItem = {
        productId: productId,
      };
      state.wishListItems = [...state.wishListItems, newItem]; // Create a new array with the existing items and the new item
    },
    removeFromWishList: (state, action) => {
      const { productId } = action.payload;
      state.wishListItems = state.wishListItems.filter(
        (item) => item.productId !== productId
      );
    },
  },
});
export const { addToWishList, removeFromWishList } = wishListSlice.actions;

export default wishListSlice.reducer;
