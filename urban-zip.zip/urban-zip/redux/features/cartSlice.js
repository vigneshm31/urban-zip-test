
const { createSlice } = require("@reduxjs/toolkit");


// const persistState = (state) => {
//     localStorage.setItem('cartItemsList', JSON.stringify(state.cartItemsList));
//   };

// const restoreState = () => {
//     const storedState = window.localStorage.getItem('cartItemsList');
//     if (storedState) {
//       return JSON.parse(storedState);
//     }
//     return [];
//   };

const initialState = {
  cartItemsList:  [],
};
    
const cartSlice = createSlice({
  name: "cartItems",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const { productId, selectedSize, quantity } = action.payload;
      const newItem = {
        productId: productId,
        selectedSize: selectedSize,
        quantity: quantity,
      };
      state.cartItemsList = [...state.cartItemsList, newItem]; // Create a new array with the existing items and the new item
//   persistState(state)
    },
    removeFromCart: (state, action) => {
      const { productId } = action.payload;
      state.cartItemsList = state.cartItemsList.filter(
        (item) => item.productId !== productId
      );
    },
  },
});
export const { addToCart, removeFromCart } = cartSlice.actions;

export default cartSlice.reducer;
