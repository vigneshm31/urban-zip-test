const { createSlice } = require("@reduxjs/toolkit")

const initialState={
    value:0
}

const counterSlice=createSlice({
    name:"counter",//name of the slice
    initialState,//state of the slice will start with
   //reducers will take all the reducer (increment reducer and decrement reducer)
    reducers:{
        reset: () => initialState,
        //seems like directly mutable but createSLice doing the task in backward copy the state and doing the update and replace the original state
        increment:(state,payload)=>{
            state.value=state.value+1
        },
        decrement:(state,payload)=>{
            state.value=state.value-1
        },
        incrementByAmount: (state, action) => {
            state.value = state.value+action.payload;
          },
    }

})

export const {increment,decrement,reset}=counterSlice.actions
 
export default counterSlice.reducer

// define the slice create slice in up we are automatically get the access the reducer

